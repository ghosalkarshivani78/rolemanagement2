/******************************** String Constructors *******************************/
// remove spaces from left and right side
String.prototype.trim = function() {
	return this.replace(/^\s+|\s+$/g,"");
}
// to remove left side spaces from string
String.prototype.ltrim = function() {
	return this.replace(/^\s+/,"");
}
// to remove right side spaces from string
String.prototype.rtrim = function() {
	return this.replace(/\s+$/,"");
}
// to convert srting into sentence case
String.prototype.toSentenceCase = function (){
	var sAry = this.split('.')
	for (x=0;x<sAry.length;x++){
		sAry[x] = sAry[x].trim().substr(0,1).toUpperCase()+sAry[x].trim().substr(1).toLowerCase()
	}
	return sAry.join('. ')
}
// to get left side string as per length
String.prototype.left = function (x){
	return this.substr(0,x);
}
// to get right side string as per length
String.prototype.right = function (x){
	return this.substr(this.length-x,x);
}
//------------------------------------------
String.prototype.roundOff = function(_fix){
	return roundOff$(this,_fix) ;
} 
// to roundof any number as per _fix
function roundOff$(_Num, _fix){ 
	return (Math.round(_Num * (Math.pow(10, _fix)))/(Math.pow(10, _fix))).toFixed(_fix) ;
} 
//------------------------------------------
String.prototype.toDate = function(format){
	return toDate$(this,format);
}



/******************************** Miscilinious Functions ********************************************************/

//-------------------get object of given id based on given object container -----------------------
function obj$(i,d){
	var d = d || document;
	return d.getElementById(i)
}
//---------------- display object based on given object id --------------------------
function show$(i,d){
	var o;
	var d = d || document;
	if(typeof(i)=="string") o = obj$(i,d); else if(typeof(i)=="object") o = i;
	o.style.display='block';
	o.style.visibility='visible'
}
//--------------- hide object based on given object id---------------------------
function hide$(i,d){
	var o;
	var d = d || document;
	if(typeof(i)=="string") o = obj$(i,d); else if(typeof(i)=="object") o = i;
	o.style.display='none';
	o.style.visibility='hidden'
}
//--------------- toggle display based on given object id ---------------------------
function toggle$(i,d){
	var o;
	var d = d || document;
	if(typeof(i)=="string") o = obj$(i,d);
	if(typeof(i)=="object") o = i;
	if(o.style.display.toLowerCase()=='none' || o.style.visibility.toLowerCase()=='hidden'){
		show$(i);
	} else {
		hide$(i);
	}
}
//------------- set value in the given object id-----------------------------
function setValue$(i,v){
	if(typeof(i)=='string') obj$(i).value = v; else if(typeof(i)=='object') i.value = v;
}
//---------------- get value of given object id--------------------------
function getValue$(i){
	if(typeof(i)=='string') return obj$(i).value; else if(typeof(i)=='object') return i.value;
	return null;
}
// to get x,y position of an object
function getObjectPos$(obj){
	var pos = {x: obj.offsetLeft||0, y: obj.offsetTop||0};
	while(obj = obj.offsetParent) {
		pos.x += obj.offsetLeft||0;
		pos.y += obj.offsetTop||0;
	}
	return pos;
}
// to get size of the window
function getWindowSize$(){
	var size = {w:0,h:0};
	//IE
	if(!window.innerWidth){  ////strict mode
		if(!(document.documentElement.clientWidth == 0)){
			size.w = document.documentElement.clientWidth;
			size.h = document.documentElement.clientHeight;
		} else {  ////quirks mode
			size.w = document.body.clientWidth;
			size.h = document.body.clientHeight;
		}
	}else { //w3c
		size.w = window.innerWidth;
		size.h = window.innerHeight;
	}
	return size;
}

// to get object size
function getObjectSize$(e) {
	var size = {w:0, h:0};
	size.w = e.offsetWidth;
	size.h = e.offsetHeight;
	return suze;
}

// to get page scroll position
function getPageScroll$() {
	var pos = {x:0,y:0};
	if(!window.pageYOffset)	{	//strict mode
		if(!(document.documentElement.scrollTop == 0))	{
			pos.y = document.documentElement.scrollTop;
			pos.x = document.documentElement.scrollLeft;
		} else { //quirks mode
			pos.y = document.body.scrollTop;
			pos.x = document.body.scrollLeft;
		}
	} else { //w3c
		pos.y = window.pageYOffset;
		pos.x = window.pageXOffset;
	}
  return { 'x': offsetX, 'y': offsetY };
}

// to include javascript file
function includeJSFile$(srcFile){
	var script = document.createElement('script');
	script.src = srcFile;
	script.type = 'text/javascript';
	var head = document.getElementsByTagName('head')[0];
	head.appendChild(script)
}

// to know browser
function getBrowser$(){
	var agt = navigator.userAgent.toLowerCase();
	var browser = {	ms : agt.indexOf("msie") > 0 ? true : false,
					ns : agt.indexOf('netscape') ? true : false,
					so : agt.indexOf('staroffice') ? true : false,
					op : agt.indexOf('opera') ? true : false,
					wt : agt.indexOf('webtv') ? true : false,
					bx : agt.indexOf('beonex') ? true : false,
					cm : agt.indexOf('chimera') ? true : false,
					np : agt.indexOf('netpositive') ? true : false,
					px : agt.indexOf('phoenix') ? true : false,
					fx : agt.indexOf('firefox') ? true : false,
					sf : agt.indexOf('safari') ? true : false,
					ss : agt.indexOf('skipstone') ? true : false,
					mz : agt.indexOf('mozilla') ? true : false
				}
	return browser;
}

// to insert object after given object
function insertAfter$(new_node, existing_node) {  
	if (existing_node.nextSibling)   
		existing_node.parentNode.insertBefore(new_node, existing_node.nextSibling);
	else
		existing_node.parentNode.appendChild(new_node);
}

// to set cookies
function setCookie$( name, value, expires, path, domain, secure ) {
	var today = new Date();
	today.setTime( today.getTime() );
	if ( expires )
		expires = expires * 1000 * 60 * 60 * 24;
	var expires_date = new Date( today.getTime() + (expires) );
	document.cookie = name + "=" +value + (( expires ) ? ";expires=" + expires_date.toGMTString() : "" ) + (( path ) ? ";path=" + path : "" ) + (( domain ) ? ";domain=" + domain : "" ) +(( secure ) ? ";secure" : "" );
}

// to get cookies
function getCookie$(name){
	var dc = document.cookie;
	var prefix = name + "=";
	var begin = dc.indexOf("; " + prefix);
	if (begin == -1){
		begin = dc.indexOf(prefix);
		if (begin != 0) return null;
	} else {
		begin += 2;
	}
	var end = document.cookie.indexOf(";", begin);
	if (end == -1){
		end = dc.length;
	}
	return (dc.substring(begin + prefix.length, end));
}
// to delete cookies
function deleteCookie$(name, path, domain){
	if (getCookie(name)){
		document.cookie = name + "=" + 
		((path) ? "; path=" + path : "") +
		((domain) ? "; domain=" + domain : "") + "; expires=Thu, 01-Jan-70 00:00:01 GMT";
	}
}

// to check date1 greater that date2 by ID
function dateCompareById$(di1,di2,format){
	return dateCompare(toDate(getValue(di1),format),toDate(getValue(di2),format))
}

// to check date1 greater that date2 by Value
function dateCompareByValue$(dv1,dv2,format){
	return dateCompare(toDate(dv1,format),toDate(dv2,format))
}

// to check date1 greater that date2 by Object
function dateCompare$(do1,do2){
	if(do1==null || do2==null) return false;
	if (do1 > do2) return true; else return false;
}
// to find date difference in days
function dateDiffById$(di1,di2,format){
	return dateDiff(toDate(getValue(di1),format),toDate(getValue(di2),format))
}

// to find date difference in days
function dateDiffById$(dv1,dv2,format){
	return dateDiff(toDate(dv1,format),toDate(dv2,format))
}

// to find date difference in days
function dateDiff$(do1,do2){
	if(do1 == null || do2 == null) return 0;
	var timeDiff = do2.getTime() - do1.getTime();
	var dayDiff = timeDiff / 1000 / 60 / 60 / 24;
	return dayDiff
}
// to get max out of two values
function getMax$(v1,v2){
	if (v1 > v2) return v1; else return v2;
}

// to set empty string in the object id
function setEmpty$(id){
	setValue$(id,"")
}

//BI has added this function to get back to AwardslinQ
function backToMerch() {
document.getElementById('returnWarning').style.display = 'block';
}
function backToTravel() {
document.getElementById('returnWarning').style.display = 'none';
}

function setClass(element,className){
	element.setAttribute('class',className);
	element.setAttribute('className',className); //<iehack>
}

var waitWindow;
function showWaitInProgress(){
	var wintInProgress = document.getElementById('wintInProgress');
	if (! wintInProgress){
		var wintInProgress = document.createElement('div');
		wintInProgress.id = 'wintInProgress';
		wintInProgress.innerHTML = "<div class='wintInProgress' onclick='hideWaitInProgress()'>Please wait, we are processing your request....<div/>";
		document.body.appendChild(wintInProgress);
	}
	waitWindow = dhtmlmodal.open('modalwaitwindow','div','wintInProgress','Request in progress...','title=1,width=350,height=100,center=1');
}

function hideWaitInProgress(){
   if(waitWindow) waitWindow.hide();
}
function right(value, x){return value.substr(value.length-x,x);}
function openacc_tabs(el){
	var elParent = el.parentNode;
	var elpList = elParent.getElementsByTagName('li');
	for (var x=0;x<elpList.length ;x++ ){
		setClass(elpList[x],'acc_Tab');
		var os = obj$('acc_tab'+ x);
		hide$(os);
	}
	setClass(el,'acc_TabSelected')
	var nObj = 'acc_tab'+right(el.id,1);
//	sh=sh
	show$(nObj);
	}


function dateTime (){
	Stamp = new Date();
	year = Stamp.getYear();
	if (year < 2000) year = 1900 + year;
	document.write('' + (Stamp.getMonth() + 1) +"/"+Stamp.getDate()+ "/"+ year + '');
	var Hours;
	var Mins;
	var Time;
	Hours = Stamp.getHours();
	if (Hours >= 12) {
	Time = " P.M.";
	}
	else {
	Time = " A.M.";
	}

	if (Hours > 12) {
	Hours -= 12;
	}

	if (Hours == 0) {
	Hours = 12;
	}

	Mins = Stamp.getMinutes();

	if (Mins < 10) {
	Mins = "0" + Mins;
	}

	document.write(' ' + Hours + ":" + Mins + Time + '');
}
