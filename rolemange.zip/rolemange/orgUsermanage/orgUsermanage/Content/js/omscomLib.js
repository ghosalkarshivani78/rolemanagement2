
function opentabFlight(){
	 hide$('ImportPnr');
	 hide$('ImportPnrCont');
	 show$('flighttab');
	 show$('flighttabCont');
	}
function opentabImpnr(){
	 hide$('flighttab');
	 hide$('flighttabCont');
	 show$('ImportPnr');
	 show$('ImportPnrCont');
	}


function openchangestatus(){
	openchange = dhtmlmodal.open('openchange','iframe','changeStatusOrder.html','Change Status Order','title=1,close=1,drag=1,width=530,height=215,center=1,scrolling=1');
}

function closeWindowPage(url){
  // self.close();
var pp = window.parent ? window.parent : window.top;
//pp.f1.hide();
pp.window.location.href=url
} 
function openForAssignTo(){
	openchange = dhtmlwindow.open('openAssinChange','iframe','assignto.html','Select Role to Assign','title=1,close=1,drag=1,height=225,width=315,center=1,scrolling=1');
}
function closeForAssignTo(){
	hide$('openAssinChange',parent.document);
}
function openShowHistory(){
	openShoistory = dhtmlwindow.open('SH','iframe','showHistory.html','Booking History ','title=1,close=1,drag=1,height=228,width=920,center=1,scrolling=1');
}
function closeShowHistory(){
	hide$('SH',parent.document);
}
function openFareDetails(){
	openShoistory = dhtmlwindow.open('FD','iframe','paymentdetails.html','Fare Details','title=1,close=1,drag=1,height=320,width=425,center=1,scrolling=1');
}
function closeFareDetails(){
	hide$('FD',parent.document);
}
function openFareRules(){
	openFareRul = dhtmlmodal.open('FR','iframe','fareRules.html','Fare Rule','title=1,close=1,drag=1,height=400,width=530,center=1,scrolling=1');
}


function openseatRequest(){
	openFareRul = dhtmlmodal.open('SR','iframe','seatRequest.html','Seat Request','title=1,close=1,drag=1,height=200,width=380,center=1,scrolling=1');
}
function opentickitRequest(){
	openFareRul = dhtmlmodal.open('SR','iframe','tikitrequest.html','Ticket Request','title=1,close=1,drag=1,height=200,width=380,center=1,scrolling=1');
}
function closeseatRequest(){
	hide$('SR',parent.document);
}
function openEditRequest(){
	openEditReq = dhtmlmodal.open('openEditReqd','iframe','editFlightDetails.html','Update Flight/Traveller Details','title=1,close=1,drag=1,height=250,width=830,center=1,scrolling=1');
}
function closeOpenEditReq(){
	hide$('openEditReqd',parent.document);
}
function openGenratePNR(){
	opengeneratePNR = dhtmlmodal.open('GP','iframe','generatePnr.html','Genrate PNR','title=1,close=1,drag=1,height=115,width=280,center=1,scrolling=1');
}
function closeGenratePNR(){
	hide$('GP',parent.document);
}
function openUpdatePNR(){
	opengeneratePNR = dhtmlmodal.open('GP','iframe','generatePnr.html','Update PNR','title=1,close=1,drag=1,height=115,width=280,center=1,scrolling=1');
}

function openGerateTicket(){
	openGerateTicketv = dhtmlmodal.open('GT','iframe','generateticket.html','Generate Ticket','title=1,close=1,drag=1,height=215,width=400,center=1,scrolling=1');
}
function closeGerateTicket(){
	hide$('GT',parent.document);
}
function openpostComment(){
	openpostCommentobj = dhtmlwindow.open('postComment','iframe','postComments.html','Post Comments','title=1,close=1,drag=1,height=160,width=395,center=1,scrolling=1');
}
function closepostComment(){
	hide$('postComment',parent.document);
}
function openTransactionEdit(){
	openTransactionDetailsEdit = dhtmlwindow.open('TDE','iframe','transactionDetailsedit.html','Edit Payment','title=1,close=1,drag=1,height=250,width=525,center=1,scrolling=1');
}
function closeTransactionEdit(){
	hide$('TDE',parent.document);
}
function openChargeBack(){
	openTransactionChargeBackt = dhtmlwindow.open('ChargeBack','iframe','cargeBack.html','Charge Back','title=1,close=1,drag=1,height=130,width=250,center=1,scrolling=1');
}
function closeChargeBack(){
	hide$('ChargeBack',parent.document);
}
function openTransactionExtraCharge(){
	openTransactionDetailsExtraCharge = dhtmlwindow.open('extracharge','iframe','transactionDetailsextracharge.html','Extra Charge','title=1,close=1,drag=1,height=220,width=550,center=1,scrolling=1');
}
function closeTransactionExtraCharge(){
	hide$('extracharge',parent.document);
}
function openTransactionNewPayment(){
	openTransactionDetailsExtraCharge = dhtmlwindow.open('NewPayment','iframe','transactionDetailsnewpayment.html','Make New Payment','title=1,close=1,drag=1,height=220,width=550,center=1,scrolling=1');
}
function closeTransactionNewPayment(){
	hide$('NewPayment',parent.document);
}
function dateTime (){
	Stamp = new Date();
	year = Stamp.getYear();
	if (year < 2000) year = 1900 + year;
	document.write('' + (Stamp.getMonth() + 1) +"/"+Stamp.getDate()+ "/"+ year + '');
	var Hours;
	var Mins;
	var Time;
	Hours = Stamp.getHours();
	if (Hours >= 12) {
	Time = " P.M.";
	}
	else {
	Time = " A.M.";
	}

	if (Hours > 12) {
	Hours -= 12;
	}

	if (Hours == 0) {
	Hours = 12;
	}

	Mins = Stamp.getMinutes();

	if (Mins < 10) {
	Mins = "0" + Mins;
	}

	document.write(' ' + Hours + ":" + Mins + Time + '');
}

function openwindow(){
	var newwindow = window.open('sampleemailpreview.html','_blank','height=600,width=1014,location=0,menubar=0,toolbar=0,scrollbars=1,status=1,top=0,left=0');
	
}
function opencrepticCommandHis(){
	opencrepticHistory = dhtmlwindow.open('opencrepticCommandHis','div','commandhistory','Command History','title=1,close=1,drag=1,height=200,width=525,center=1,scrolling=1');
}

function openchangestatushotel(){
	openchange = dhtmlmodal.open('openchange','iframe','changeStatusOrder.html','Change Status Order','title=1,close=1,drag=1,width=530,height=215,center=1,scrolling=1');
}
function openchangestatuscar(){
	openchange = dhtmlmodal.open('openchange','iframe','carchangeStatusOrder.html','Change Status Order','title=1,close=1,drag=1,width=520,height=205,center=1,scrolling=1');
}

function opencPackagedetails(){
	openPackagedetails = dhtmlmodal.open('Packagedetailsf','div','packagedetails','Package Details','title=1,close=1,drag=1,width=630,height=305,center=1,scrolling=1');
}
function openFareDetailshotel(){
	openShoistory = dhtmlwindow.open('FDhotel','iframe','hotelpaymentdetails.html','Fare Details','title=1,close=1,drag=1,height=230,width=440,center=1,scrolling=1');
}
function closeFareDetailshotel(){
	hide$('FDhotel',parent.document);
}
function openEditRequesthotel(){
	openEditReq = dhtmlmodal.open('openEdithotel','iframe','edithotelDetails.html','Update Hotel Details','title=1,close=1,drag=1,height=400,width=850,center=1,scrolling=1');
}
function closeOpenEditReqhotel(){
	hide$('openEdithotel',parent.document);
}

function openHotelDetails(){
	openEditReq = dhtmlmodal.open('hotelDetails','iframe','hoteldetailsrew.html','Hotel Details','title=1,close=1,drag=1,height=200,width=515,center=1,scrolling=1');
}
function closeHotelDetails(){
	hide$('hotelDetails',parent.document);
}

function openVLMmenu(el,DivId){
	if(el.className=='itemClose')
		el.className='itemopen';
	else
		el.className='itemClose';
		
	toggle$(DivId)
}
	
function openclrReport(){
	show$('report1');
	hide$('report2'); 
	hide$('report3'); 
	hide$('report4'); 
	hide$('report5');
	show$('selctclm'); 
	hide$('selctchek');
	hide$('misselect');
	show$('misselectnone');
	hide$('prselect');
	show$('prselectnone');
	hide$('PRselctchek');
	hide$('PROselctnone');
	show$('PRselctclm');
}
function openmisReport() {
	hide$('report1');
	hide$('report2'); 
	hide$('report3'); 
	show$('report4'); 
	hide$('report5');
	hide$('selctclm');
	show$('selctchek'); 
	hide$('misselectnone');
	show$('misselect');
	hide$('prselect');
	show$('prselectnone');
	hide$('PRselctchek');
	hide$('PROselctnone');
	show$('PRselctclm');
}
function openOrderReport() {
	hide$('report1');
	show$('report2');
	hide$('report3'); 
	hide$('report4');
	hide$('report5');
	show$('selctchek'); 
	hide$('selctclm');
	hide$('misselect');
	show$('misselectnone');
	hide$('prselect');
	show$('prselectnone');
	show$('PRselctchek');
	hide$('PROselctnone');
	hide$('PRselctclm');
}
function opensubReport() {
	hide$('report1');
	hide$('report2');
	show$('report3'); 
	hide$('report4');
	hide$('report5');
	show$('selctchek'); 
	hide$('selctclm');
	hide$('misselect');
	show$('misselectnone');
	hide$('prselect');
	show$('prselectnone');
	hide$('PRselctchek');
	show$('PROselctnone');
	hide$('PRselctclm');
}
function openProReport() {
	hide$('report1');
	hide$('report2');
	hide$('report3'); 
	hide$('report4');
	show$('report5');
	show$('selctchek'); 
	hide$('selctclm');
	hide$('misselect');
	show$('misselectnone');
	show$('prselect');
	hide$('prselectnone');
	hide$('PRselctchek');
	hide$('PROselctnone');
	show$('PRselctclm');
}

function setCheckUncheckAll(el,selectAllid){
	var oList = document.getElementsByName(el.name);
	var allStatus = true;
	for (var x=0;x<oList.length && allStatus ;x++ ){
		if (oList[x].checked==false) {allStatus = false;}
	}
	obj$(selectAllid).checked = allStatus;
}

function checkUncheckAll(el,listName){
	var oList = document.getElementsByName(listName);
	for (var x=0;x<oList.length ;x++ ){
		oList[x].checked = el.checked;
	}
}

function opentab1(){
	 hide$('hotelTab');
	 hide$('villaTab');
	 hide$('toursTab');
 	 hide$('transTab');
 	 hide$('carTab');
	 show$('flightTab');
     hide$('package');
	 hide$('flightofflineTab');
	 hide$('hotelofflineTab');
     hide$('XOTab');
	 hide$('ImportPnrCont'); 
	 hide$('trainTab');
	 show$('select1');
	hide$('select2');
	hide$('select3');
	hide$('select4');
	hide$('select5');
	hide$('select6');
	hide$('select7');
	hide$('select8');
	hide$('select9');
	hide$('select10');
	hide$('select11');
	hide$('select12');
	}
function opentab2(){
	 show$('hotelTab');
	 hide$('villaTab');
	 hide$('toursTab');
 	 hide$('transTab');
 	 hide$('carTab');
	 hide$('flightTab');
   hide$('package');
    hide$('flightofflineTab');
	 hide$('hotelofflineTab');
     hide$('XOTab');
	 hide$('ImportPnrCont');
	  hide$('trainTab');
	 hide$('select1');
	show$('select2');
	hide$('select3');
	hide$('select4');
	hide$('select5');
	hide$('select6');
	hide$('select7');
	hide$('select8');
		hide$('select9');
	hide$('select10');
	hide$('select11');
	hide$('select12');
	}
function opentab3(){
	hide$('hotelTab');
	 show$('villaTab');
	 hide$('toursTab');
 	 hide$('transTab');
 	 hide$('carTab');
	 hide$('flightTab');
   hide$('package');
    hide$('flightofflineTab');
	 hide$('hotelofflineTab');
     hide$('XOTab');
	 hide$('ImportPnrCont');
	  hide$('trainTab');
	 hide$('select1');
	hide$('select2');
	show$('select3');
	hide$('select4');
	hide$('select5');
	hide$('select6');
	hide$('select7');
	hide$('select8');
	hide$('select9');
	hide$('select10');
	hide$('select11');
	hide$('select12');
	}
function opentab4(){
	hide$('hotelTab');
	 hide$('villaTab');
	 show$('toursTab');
 	 hide$('transTab');
 	 hide$('carTab');
	 hide$('flightTab');
   hide$('package');
    hide$('flightofflineTab');
	 hide$('hotelofflineTab');
     hide$('XOTab');
	 hide$('ImportPnrCont');
	  hide$('trainTab');
	 hide$('select1');
	hide$('select2');
	hide$('select3');
	show$('select4');
	hide$('select5');
	hide$('select6');
	hide$('select7');
	hide$('select8');
	hide$('select9');
	hide$('select10');
	hide$('select11');
	hide$('select12');
	}
function opentab5(){
	hide$('hotelTab');
	 hide$('villaTab');
	 hide$('toursTab');
 	 show$('transTab');
 	 hide$('carTab');
	 hide$('flightTab');
	  hide$('package');
	   hide$('flightofflineTab');
	 hide$('hotelofflineTab');
     hide$('XOTab');
	 hide$('ImportPnrCont');
 hide$('trainTab');
	hide$('select1');
	hide$('select2');
	hide$('select3');
	hide$('select4');
	show$('select5');
	hide$('select6');
	hide$('select7');
	hide$('select8');
	hide$('select9');
	hide$('select10');
	hide$('select11');
	hide$('select12');
	}
function opentab6(){
	hide$('hotelTab');
	 hide$('villaTab');
	 hide$('toursTab');
 	 hide$('transTab');
 	 show$('carTab');
	 hide$('flightTab');
	  hide$('package');
	   hide$('flightofflineTab');
	 hide$('hotelofflineTab');
     hide$('XOTab');
	 hide$('ImportPnrCont');
	  hide$('trainTab');
	hide$('select1');
	hide$('select2');
	hide$('select3');
	hide$('select4');
	hide$('select5');
	show$('select6');
	hide$('select7');
	hide$('select8');
	hide$('select9');
	hide$('select10');
	hide$('select11');
	hide$('select12');
	}
function opentab7(){
	hide$('hotelTab');
	 hide$('villaTab');
	 hide$('toursTab');
 	 hide$('transTab');
 	 hide$('carTab');
	 hide$('flightTab');
	 show$('package');
	  hide$('flightofflineTab');
	 hide$('hotelofflineTab');
     hide$('XOTab');
	 hide$('ImportPnrCont');
	  hide$('trainTab');
	hide$('select1');
	hide$('select2');
	hide$('select3');
	hide$('select4');
	hide$('select5');
	hide$('select6');
	show$('select7');
	hide$('select8');
	hide$('select9');
	hide$('select10');
	hide$('select11');
	hide$('select12');
	}
function opentab8(){
	hide$('hotelTab');
	 hide$('villaTab');
	 hide$('toursTab');
 	 hide$('transTab');
 	 hide$('carTab');
	 hide$('flightTab');
	 hide$('package');
	 hide$('flightofflineTab');
	 hide$('hotelofflineTab');
    hide$('XOTab');
	show$('ImportPnrCont');
	 hide$('trainTab');
	hide$('select1');
	hide$('select2');
	hide$('select3');
	hide$('select4');
	hide$('select5');
	hide$('select6');
	hide$('select7');
	show$('select8');
	hide$('select9');
	hide$('select10');
	hide$('select11');
	hide$('select12');
	}
	function opentab9(){
	hide$('hotelTab');
	 hide$('villaTab');
	 hide$('toursTab');
 	 hide$('transTab');
 	 hide$('carTab');
	 hide$('flightTab');
	 hide$('package');
	 show$('flightofflineTab');
	 hide$('hotelofflineTab');
    hide$('XOTab');
	hide$('ImportPnrCont');
	 hide$('trainTab');
	hide$('select1');
	hide$('select2');
	hide$('select3');
	hide$('select4');
	hide$('select5');
	hide$('select6');
	hide$('select7');
	hide$('select8');
	show$('select9');
	hide$('select10');
	hide$('select11');
	hide$('select12');
	}
	function opentab10(){
	hide$('hotelTab');
	 hide$('villaTab');
	 hide$('toursTab');
 	 hide$('transTab');
 	 hide$('carTab');
	 hide$('flightTab');
	 hide$('package');
	 hide$('flightofflineTab');
	 show$('hotelofflineTab');
    hide$('XOTab');
	hide$('ImportPnrCont');
	 hide$('trainTab');
	hide$('select1');
	hide$('select2');
	hide$('select3');
	hide$('select4');
	hide$('select5');
	hide$('select6');
	hide$('select7');
	hide$('select8');
	hide$('select9');
	show$('select10');
	hide$('select11');
	hide$('select12');
	}
	function opentab11(){
	hide$('hotelTab');
	 hide$('villaTab');
	 hide$('toursTab');
 	 hide$('transTab');
 	 hide$('carTab');
	 hide$('flightTab');
	 hide$('package');
	 hide$('flightofflineTab');
	 hide$('hotelofflineTab');
    show$('XOTab');
	hide$('ImportPnrCont');
	 hide$('trainTab');
	hide$('select1');
	hide$('select2');
	hide$('select3');
	hide$('select4');
	hide$('select5');
	hide$('select6');
	hide$('select7');
	hide$('select8');
	hide$('select9');
	hide$('select10');
	show$('select11');
	hide$('select12');
	}
function opentab12(){
	 hide$('hotelTab');
	 hide$('villaTab');
	 hide$('toursTab');
 	 hide$('transTab');
 	 hide$('carTab');
	 hide$('flightTab');
 	 show$('trainTab');

     hide$('package');
	 hide$('flightofflineTab');
	 hide$('hotelofflineTab');
     hide$('XOTab');
	 hide$('ImportPnrCont');
	hide$('select1');
	hide$('select2');
	hide$('select3');
	hide$('select4');
	hide$('select5');
	hide$('select6');
	hide$('select7');
	hide$('select8');
	hide$('select9');
	hide$('select10');
	hide$('select11');
	show$('select12')
	}
function opentoggle(el,DivId){
	if(el.className=='topItemClose')
		el.className='topItemopen';
	else
		el.className='topItemClose';
		
	toggle$(DivId)
}
function opentogglehis(el,DivId){
	if(el.className=='historyClose')
		el.className='historyopen';
	else
		el.className='historyClose';
		
	toggle$(DivId)
}
function openTraveler(){
	openTravel = dhtmlmodal.open('openraveler','div','TravelerF','Travellers Information','title=1,close=1,drag=1,height=200,width=950,center=1,scrolling=1');
}

function openTravelerH(){
	openTravelH = dhtmlmodal.open('openravelerH','div','TravelerH','Travellers Information','title=1,close=1,drag=1,height=260,width=600,center=1,scrolling=1');
}

function openhoteldetailsH(){
	openhotelH = dhtmlmodal.open('hoteltdetailsH','div','HoteldetailsH','Hotel Details','title=1,close=1,drag=1,height=250,width=510,center=1,scrolling=1');
}
function openHotelamenities(){
	openamenities = dhtmlmodal.open('amenities','div','Hotelamenities','Hotel Amenities','title=1,close=1,drag=1,height=250,width=510,center=1,scrolling=1');
}
function openvillaamenities(){
	openVamenities = dhtmlmodal.open('Vamenities','div','villaamenities','Villa Amenities','title=1,close=1,drag=1,height=250,width=510,center=1,scrolling=1');
}
function openTravelerV(){
	openTravelV = dhtmlmodal.open('openravelerV','div','TravelerV','Travellers Information','title=1,close=1,drag=1,height=260,width=600,center=1,scrolling=1');
}
function openDetailsV(){
	opendtailsVi = dhtmlmodal.open('opendtailV','div','VillaDetails','Villa Details','title=1,close=1,drag=1,height=250,width=510,center=1,scrolling=1');
}
function openTravelerTours(){
	openTravelT = dhtmlmodal.open('openravelerT','div','TravelerTours','Travellers Information','title=1,close=1,drag=1,height=260,width=600,center=1,scrolling=1');
}
function openToursdetails(){
	openToursdetailsT = dhtmlmodal.open('ToursdetailsT','div','Toursdetails','Tours Details','title=1,close=1,drag=1,height=365,width=930,center=1,scrolling=1');
}
function openTravelerTrans(){
	openTraveltr = dhtmlmodal.open('openravelerTr','div','TravelerTrans','Travellers Information','title=1,close=1,drag=1,height=260,width=600,center=1,scrolling=1');
}
function opentransferdeails(){
	opentrlsr = dhtmlmodal.open('otransferdeailsr','div','transferdeails','Transfer Details','title=1,close=1,drag=1,height=365,width=930,center=1,scrolling=1');
}
function openTravelerCar(){
	openTraveltr = dhtmlmodal.open('openravelerTr','div','Travelercars','Travellers Information','title=1,close=1,drag=1,height=100,width=420,center=1,scrolling=1');
}
function openForPrint(){
	var newwindow = window.open('printhistory.html','_blank','height=600,width=900,location=0,menubar=0,toolbar=0,scrollbars=1,status=1,center=1,top=0, left=0');
	if(window.focus) {newwindow.focus();newwindow.print(); }
}
function openpeyDetails(){
	openTraveltr = dhtmlmodal.open('peymentDetails','div','peyDetails','Payment Detials','title=1,close=1,drag=1,height=465,width=480,center=1,scrolling=1');
}

function openTraveler_train(){
	openTravel = dhtmlmodal.open('openraveler','div','TravelerTrain','Travellers Information','title=1,close=1,drag=1,height=200,width=950,center=1,scrolling=1');
}

function selectparty(el){
	switch (el.id){
		case "agentRadio" :
				show$('agent');
				hide$('vendor');
				break;
		case "vendorRadio" :
				hide$('agent');
				show$('vendor');
				break;

	}
}
function doSearch(){
	if (obj$('agentRadio').checked){
		window.location.href='agentsettlement.html'
	}else {
		window.location.href='vendorsettlement.html'
	}
}
function mailtopopup(){
	mailtoWindow = dhtmlmodal.open('mailPopup', 'div', 'mailto', 'Email', 'width=520px,height=310,left=150px,top=100px,resize=0,scrolling=1,center=1"')
}
function openForPrint(){
	var newwindow = window.open('printvenderprocess.html','_blank','height=600,width=840,location=0,menubar=0,toolbar=0,scrollbars=1,status=1');
	if(window.focus) {newwindow.focus();newwindow.print(); }
}
function openForPrint2(){
	var newwindow2 = window.open('printagentprocess.html','_blank','height=600,width=840,location=0,menubar=0,toolbar=0,scrollbars=1,status=1');
	if(window.focus) {newwindow.focus();newwindow.print(); }
}