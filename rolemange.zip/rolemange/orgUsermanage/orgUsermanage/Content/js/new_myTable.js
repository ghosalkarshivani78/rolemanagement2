//------------------------------------------------------------------
function myTable(_cid,_header,_rows,_footer,options){
	this.container = document.getElementById(_cid);
	if (! this.container || typeof(this.container) == 'undefined'){
		alert('Invalid table container...')
		return false;
	}

	function getHTMLTable(_rows){
		var t = document.getElementById(_rows)
		var rows = t.rows
		var tData= new Array()
		for(x=0 ;x<rows.length;x++){
			var cells = rows[x].cells;
			var tRow = new Array()
			if(cells[0].tagName != "TH"){
				for(y=0;y<cells.length;y++){
					tRow[y] = cells[y].innerHTML
				}
				tData[tData.length] = tRow;
			}
		}
		t.style.display='none';
		return tData;
	}

	function getXMLData(_rows){
		var rows = _rows
		var tData= new Array()
		for(x=0 ;x<rows.length;x++){
			var cells = rows[x].getElementsByTagName('Cell');
			var tRow = new Array()
			for(y=0;y<cells.length;y++){
				tRow[y] = cells[y].firstChild.nodeValue;
			}
			tData[tData.length] = tRow;
		}
		return tData;
	}

	this.container.innerHTML='';
	this.cId = _cid;
	this.tHeader = _header || {};
	this.tRows = _rows || new Array();
	this.tFooter = _footer || new Array();
	this.options = options || { };
	this.input = this.options.input || 'A';
	if(this.input.toUpperCase().substr(0,1) == 'T'){
		this.tRows = getHTMLTable(_rows)
	} else if(this.input.toUpperCase().substr(0,1) == 'X'){
		this.tRows = getXMLData(_rows)
	}
	this.title = this.options.title || null;
	this.title = (this.title && this.title.length > 0 ? this.title : null);
	this.tClass = this.options.className || 'mytables';
	this.tType = this.options.type || 'P';
	this.tType = this.tType.toUpperCase().substr(0,1);
	this.tHeight = this.options.height || (this.tType == 'P' ? 10 : 200);
	this.tLang = this.options.lang || {};
	this.filterInput="";
	this.dataArray = this.tRows;
	this.noOfCols = this.tHeader.length || 0;
	this.displayableCols = 0;
	this.tWidth = 0 ;
	this.rHeight = 18;
	this.tHeadHeight = 22;
	this.dataRowsHeight = 0;
	this.scrollbarWidth = 0 ;
	this.noOfRowsPerPage = (this.tType == 'P' ? this.tHeight : 0);
	this.noOfRows = 0;
	this.noOfFilteredRows = 0;
	this.noOfPages = 1;
	this.browser = this.getBrowser(); 
	for (var x=0;x<_header.length ;x++ ){
		if (typeof(_header[x].width) == 'undefined' || _header[x].width == null) this.tHeader[x].width = 50 ; else this.tHeader[x].width = parseInt(this.tHeader[x].width);
		if (typeof(_header[x].filter) == 'undefined' || _header[x].sortable == null) this.tHeader[x].filter = false;
		if (typeof(_header[x].sortable) == 'undefined' || _header[x].sortable == null) this.tHeader[x].sortable = false;
		if (typeof(_header[x].sort_type) == 'undefined' || _header[x].sort_type == null) this.tHeader[x].sort_type = 'TEXT';
		if (typeof(_header[x].display) == 'undefined' || _header[x].display == null) this.tHeader[x].display = true;
		if (typeof(_header[x].toolTip) == 'undefined' || _header[x].toolTip == null) this.tHeader[x].toolTip = false;
		if (typeof(_header[x].toolTipText) == 'undefined' || _header[x].toolTipText == null) this.tHeader[x].toolTipText = "";
		if (typeof(_header[x].align) == 'undefined' || _header[x].align == null) this.tHeader[x].align = 'left';
	}
	this.dataTable;
	this.tableHeading;
	this.tableRows;
	this.divRows;
	this.tableFooter;
	this.tableFooterPagination;
	this.config();
	this.createMyTable();
	this.visible ? this.show() : this.hide();
	if (this.tType =='S' ) { this.divRows.style.width = this.tableHeading.offsetWidth + (this.browser.ns ? -1:0); }
	return this;
};
//-----------------------------------------------------------------------------
myTable.prototype.config = function (){
	this.setTableHeight();
	this.setTableWidth();
	this.setLang();
	this.visible = true;
};
//-----------------------------------------------------------------------------
myTable.prototype.setTableHeight = function (){
	this.dataRowsHeight =  this.tHeight - this.tHeadHeight;
	this.noOfRows = this.tRows.length;
	this.noOfFilteredRows = this.tRows.length;
	if (this.tType == 'S'){
		if (this.tHeight < 100)	{ this.tHeight = 100; }
		this.scrollbarWidth =  18 + (this.browser.ns ? -5:0); 
		this.tableHeight = this.tHeight
	}
	if (this.tType == 'P'){
		this.noOfPages =Math.ceil(this.noOfRows / this.noOfRowsPerPage);
		this.tableHeight = this.noOfRowsPerPage * this.rHeight;
	}
};
//-----------------------------------------------------------------------------
myTable.prototype.setTableWidth = function (){
	for (var x=0;x<this.tHeader.length ;x++ ){
		if (this.tHeader[x].display){
			this.displayableCols++;
			if (this.tHeader[x].filter)	
				this.tHeader[x].width += 12;
			this.tWidth += parseInt(this.tHeader[x].width) ; 
		}
	}
	this.tWidth += this.scrollbarWidth;
};
//-----------------------------------------------------------------------------
myTable.prototype.show = function () {
	this.dataTable.style.display = 'block';
	this.visible = true;
};
//-----------------------------------------------------------------------------
myTable.prototype.hide = function () {
	this.dataTable.style.display = 'none';
	this.visible = false;
};
//-----------------------------------------------------------------------------
myTable.prototype.toggle = function () {
	if(this.visible) { this.hide(); }
	else { this.show();}
};
//-----------------------------------------------------------------------------
myTable.prototype.setLang = function() {
	this.sortText = this.tLang.sortText || "click to sort on ";
	this.ofText = this.tLang.ofText || "of";
	this.pageText = this.tLang.pageText || "page(s)";
	this.totalText = this.tLang.totalText || "Total:";
	this.rowText = this.tLang.rowText || "row(s)";
	this.firstPageText = this.tLang.firstPageText || "first page";
	this.prevPageText = this.tLang.prevPageText || "previous page";
	this.nextPageText = this.tLang.nextPageText || "next page";
	this.lastPageText = this.tLang.lastPageText || "last page";
	this.sRowsPerPageText = this.tLang.rowsPerPageText || "Rows/Page:";
	this.months = this.tLang.months || ['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];
	myTableMonths = this.months;
};
//-----------------------------------------------------------------------------
function toDate(s,months){
	if(months == null) months = myTableMonths;
	var _date = s;
	if (typeof(s)=='string'){
		var _sDate=s.split("-");
		var _month=0;
		if(_sDate.length > 2){
			for (var x = 0; x < months.length ;x++ ){
				if(_sDate[1].toUpperCase()== months[x].toUpperCase()) {
					_month=x;
					break;
				}
			}
			_date = new Date(_sDate[2],_month,_sDate[0]);
		}
	}
	return _date;
};
//-----------------------------------------------------------------------------
myTable.prototype.createLoader = function () {
	this.loader = document.createElement('div')
	this.setClass(this.loader,'loader')
	this.loader.style.display = 'none';
	this.loader.style.width = this.tWidth;
	this.loader.style.height = this.tableHeight ;
	return this.loader;
};
//-----------------------------------------------------------------------------
myTable.prototype.showLoader = function () {
	this.loader.style.width = (this.dataTable.offsetWidth ? this.dataTable.offsetWidth : this.tWidth );
	this.loader.style.height = (this.dataTable.offsetHeight ? this.dataTable.offsetHeight : this.tableHeight );
	this.loader.style.display = 'block';
	this.loader.style.zIndex = 1000;
};
//-----------------------------------------------------------------------------
myTable.prototype.hideLoader = function () {
	this.loader.style.display = 'none';
};
//-----------------------------------------------------------------------------
myTable.prototype.createMyTable = function () {
	var tbody, thead,tfoot, tr, td;
	this.container.appendChild(this.createLoader());
	this.tableId = this.cId+'_table';
	this.headerId = this.cId+'_table_head';
	this.bodyId = this.cId+'_table_body';
	this.footerId = this.cId+'_table_foot';
	this.dataTable = this.createTable(this.tableId,this.tClass,0,0,this.tWidth,null,0);
	this.showLoader();
	this.dataTable.onselectstart = function() {return false;};
	this.dataTable.ondrag = function() {return false;};

	tbody = document.createElement('tbody');
	if(this.title) {
		tr = document.createElement('tr')
		td = document.createElement('td');
		this.setClass( td,'title');
		td.appendChild(this.tableCaption());
		tr.appendChild(td);
		tbody.appendChild(tr);
	}
	
	tr = document.createElement('tr')
	td = document.createElement('td');
	td.setAttribute('id',this.headerId);
	td.appendChild(this.createHeadingTable(this.headerId));
	tr.appendChild(td);
	tbody.appendChild(tr);

	tr = document.createElement('tr')
	td = document.createElement('td');
	td.setAttribute('id',this.bodyId);
	td.appendChild(this.createDataTable(this.bodyId));
	tr.appendChild(td);
	tbody.appendChild(tr);
	
	tr = document.createElement('tr')
	td = document.createElement('td');
	td.setAttribute('id',this.footerId);
	td.appendChild(this.createFooterTable(this.footerId));
	tr.appendChild(td);
	tbody.appendChild(tr);

	this.loader.style.display = 'none'
	this.dataTable.appendChild(tbody);
	this.dataTable.owner = this;
	this.container.appendChild(this.dataTable);
	this.hideLoader();
	
	this.filterPopup = document.createElement('div');
	this.setClass( this.filterPopup,'filterpopup');
	this.filterPopup.innerHTML = '<label id="1">1</label>&nbsp;<select><option value="S">Start with</option><option value="E">End with</option><option value="C">Contain</option></select>&nbsp;<input type="text" value=""><div><div class="filterButton" id="reset" >Reset</div><div class="filterButton" id="cancel">Cancel</div><div class="filterButton" id="apply">Apply</div></div>'

	this.container.appendChild(this.filterPopup);
};
//-----------------------------------------------------------------------------
myTable.prototype.tableCaption = function () {
	var lable = document.createElement('lable')
	lable.innerHTML = this.title
	return lable;
};
//-----------------------------------------------------------------------------
myTable.prototype.createHeadingTable = function (hId) {
	var tableHeadingId = hId +'_table';
	var tbody,tr;
	this.tableHeading = this.createTable(tableHeadingId,'heading',2,0,this.tWidth,null,0);
	thead = document.createElement('thead');
	tr = document.createElement('tr');
	for( var x = 0; x < this.noOfCols; x++) {
		if (this.tHeader[x].display){
			var th = document.createElement('th');
			var hLabel = document.createElement('div');
			th.setAttribute('id',x);
			th.onmouseover = function(){this.owner.setClass(this,'mouseover');};
			th.onmouseout = function(){this.owner.setClass(this,'');};

			th.style.width = this.tHeader[x].width - 1
			hLabel.setAttribute('id',x);			
			hLabel.style.width = this.tHeader[x].filter ? this.tHeader[x].width - 12 -1 : this.tHeader[x].width - 1
			hLabel.innerHTML = this.tHeader[x].title;
			hLabel.style.textAlign = this.tHeader[x].align;
			hLabel.owner = th.owner = this;
			if (this.tHeader[x].sortable) {
				hLabel.scope = this.tHeader[x].sort_type;
				hLabel.className= 'sortable';
				hLabel.title = this.sortText +'<'+ this.tHeader[x].title +'>'
				hLabel.onclick = function() {this.owner.showLoader(); this.owner.sortData(this);this.owner.hideLoader()}; 
			}
			th.appendChild(hLabel);
			if (this.tHeader[x].filter)	{
				var hFilter = document.createElement('div');
				hFilter.owner = this;
				hFilter.setAttribute('id',x);
				hFilter.scope = this.tHeader[x].sort_type+";"+this.tHeader[x].title;
				this.setClass(hFilter,'filter')
				hFilter.title = 'click to filter on <'+this.tHeader[x].title+'>';
				hFilter.onclick = function() {this.owner.showFilterPopup(this)}; 
				th.appendChild(hFilter);
			}
			tr.appendChild(th);
		}
	}
	if (this.tType == 'S'){
		th = document.createElement('th');
		th.style.width = this.scrollbarWidth
		tr.appendChild(th);
	}
	thead.appendChild(tr);
	this.tableHeading.appendChild(thead);
	return this.tableHeading;
};

//------------------------------------------------------------------------------

myTable.prototype.createDataTable = function(bId) {
	var tableRowsId = bId +'_table';
	var tbody;
	this.tableRows = this.createTable(tableRowsId,'datarow',2,0,this.tWidth,null,0);
	tbody = this.createDataRows(0);
	this.tableRows.appendChild(tbody);
	if (this.tType == 'S'){
		this.tableRows.style.width = this.tWidth - this.scrollbarWidth;
		this.divRows = document.createElement('div')
		this.divRows.style.height = this.dataRowsHeight;
		this.divRows.style.width = this.tWidth + (this.browser.ns ? 1 : 0);
		this.setClass(this.divRows,'datascroll');
		this.divRows.style.overflow = 'auto'
		this.divRows.appendChild(this.tableRows);
		return this.divRows
	}
	return this.tableRows;
};
//------------------------------------------------------------------------------
myTable.prototype.createDataRows = function(rowPos){
	var tbody = document.createElement('tbody');
	var dataRow;
	var c=0;
	for (var x=rowPos;x<this.noOfRows ; x++){
		tbody.appendChild(this.createRow(this.tRows[x], c++));
		if (this.tType == 'P' && c >= this.noOfRowsPerPage) { break; }
	}
	if ( this.tType == 'P' && c < this.noOfRowsPerPage && this.noOfPages > 1){
		for (x=c; x < this.noOfRowsPerPage ;x++ ) { tbody.appendChild(this.createRow(this.createEmptyRow(),c++)); }
	}
	if (this.tType == 'S' && c * this.rHeight < this.dataRowsHeight){
		for (x=c; c * this.rHeight < this.dataRowsHeight; x++){ tbody.appendChild(this.createRow(this.createEmptyRow(),c++)); }
	}
	return tbody;
};
//------------------------------------------------------------------------------
myTable.prototype.createRow = function (row , r) {
	var tr =document.createElement('tr');
	tr.id = r;
	for (var c=0;c < this.noOfCols ; c++){
		if (this.tHeader[c].display){
			td =document.createElement('td');
			span =document.createElement('span');
			td.className = (r%2 ? 'odd':'even')
			td.style.width = this.tHeader[c].width - 1; 
			td.scope=r+'~'+c
			td.style.textAlign = this.tHeader[c].align;
			if(this.tHeader[c].toolTip && (this.tHeader[c].toolTipText.length > 0))	{
				if (this.tHeader[c].toolTipText.toUpperCase() == 'DATA') {	td.title = row[c]; }
				else {	td.title = this.tHeader[c].toolTipText;}
			}
			span.innerHTML = row[c] || ' ';
			td.appendChild(span);
			tr.appendChild(td);
		}
	}
	return tr;
};
//------------------------------------------------------------------------------

myTable.prototype.createFooterTable = function(fId){
	var tableFooterId = fId +'_table'
	var tbody,tr,td,span;
	var trc,tdc,spanc;
	this.tableFooter = this.createTable(tableFooterId,'footer',2,0,'100%',null,0);
	tbody = document.createElement('tbody');
	tr =document.createElement('tr');
	if (this.tFooter.length >  0){
		for (var x=0;x<this.tHeader.length ; x++){
			if (this.tHeader[x].display){
				td =document.createElement('td');
				span =document.createElement('span');
				td.style.width = this.tHeader[x].width - 1;
				td.style.textAlign = this.tHeader[x].align;
				if ( typeof(this.tFooter[x]) != 'undefined' && this.tFooter[x] != null )
					span.innerHTML = (this.tFooter[x].length==0 ? '&nbsp;':this.tFooter[x])
				else 
					span.innerHTML = '&nbsp';
				td.appendChild(span);
				tr.appendChild(td);
			}
		}
		if (this.tType == 'S'){
			td =document.createElement('td');
			span =document.createElement('span');
			td.style.width = this.scrollbarWidth;
			td.className = 'data';
			span.innerHTML = '&nbsp;';
			td.appendChild(span);
			tr.appendChild(td);
		}
		tbody.appendChild(tr);
	}
	if (this.noOfPages > 1){ tbody.appendChild(this.createFooterPagination()); }
	this.tableFooter.appendChild(tbody);
	return this.tableFooter;
};
//------------------------------------------------------------------------------
myTable.prototype.createRowsList = function (){
	var pages = new Array();
	for (var x=0;x<this.noOfPages-1 && x < 5 ; x++){
		pages[x] = new Array((x+1)*10,(x+1)*10)
	}
	pages[x] = new Array('All',this.noOfRows)
	this.sRowsList = this.createSelect('selectrows',pages)
};
//------------------------------------------------------------------------------
myTable.prototype.createFooterPagination = function (){
	if (this.noOfPages <= 1)
		return null;
	var pagingTr =document.createElement('tr');
	var pagingTd =document.createElement('td');
	pagingTd.colSpan = this.displayableCols;
	pagingTd.setAttribute('width','100%');
	this.tableFooterPagination = this.createTable(null,'pagination',0,0,'100%',null,0);
	var tbody = document.createElement('tbody')
	var tr =document.createElement('tr');
	var td =document.createElement('td');
	var span =document.createElement('span');
	var img =document.createElement('img');
	var spanc,sPageText,sRowsText,sFiller;
	
	this.createRowsList();

	sRowsListText = span.cloneNode(true);
	sRowsListText.innerHTML = '&nbsp;'+this.sRowsPerPageText;

	sFiller = span.cloneNode(true);
	sFiller.innerHTML = ''
	sRowsText = span.cloneNode(true);
	sRowsText.innerHTML = this.totalText +'&nbsp;<span id="nooffilteredrows">'+this.noOfFilteredRows+'</span>&nbsp;of&nbsp;<span id="nooftotalrows">'+this.noOfRows+'</span>&nbsp;'+ this.rowText

	this.sRowsList.owner = this; 

	this.sRowsList.onchange = function() { this.owner.pageNavigation(this);}; 

	tdc = document.createElement('td')
	tdc.appendChild(sRowsListText);
	tdc.appendChild(this.sRowsList);
	tr.appendChild(tdc);

	tdc = document.createElement('td')
	tdc.appendChild(sRowsText);
	tr.appendChild(tdc);

	tdc = document.createElement('td')
	
	tdc.appendChild(this.createFooterPageNavigation());

	tr.appendChild(tdc);

	tbody.appendChild(tr);
	this.tableFooterPagination.appendChild(tbody);
	pagingTd.appendChild(this.tableFooterPagination)
	pagingTr.appendChild(pagingTd);

	return pagingTr;
};
//------------------------------------------------------------------------------
myTable.prototype.createPageNavigationSelect = function(){
	var pages = new Array();
	for (var x=0;x<this.noOfPages ; x++){
		pages[x] = new Array(x+1,x+1)
	}
	return this.createSelect('selectpage',pages)
};
//------------------------------------------------------------------------------
myTable.prototype.createFooterPageNavigation = function(){
	var paginationSpan =document.createElement('span');

	this.iFirst = this.createSpan('firstpage','myfirstpage','15',this.firstPageText,'&nbsp;&nbsp;&nbsp;&nbsp;');
	this.iPrev = this.createSpan('prevpage','myprevpage','15',this.prevPageText,'&nbsp;&nbsp;&nbsp;&nbsp;');
	this.iNext = this.createSpan('nextpage','mynextpage','15',this.nextPageText,'&nbsp;&nbsp;&nbsp;&nbsp;');
	this.iLast = this.createSpan('lastpage','mylastpage','15',this.lastPageText,'&nbsp;&nbsp;&nbsp;&nbsp;');

	this.sPageList = this.createPageNavigationSelect();
	this.sPageText = span.cloneNode(true);
	this.sPageText.innerHTML = '&nbsp;'+this.ofText +'&nbsp;<span id="noofpages">'+this.noOfPages+'</span>&nbsp;'+ this.pageText

	this.iFirst.owner = this.iPrev.owner = this.iNext.owner = this.iLast.owner = this.sPageList.owner = this; 

	this.iFirst.onclick = function() { this.owner.pageNavigation(this);}; 
	this.iPrev.onclick = function() { this.owner.pageNavigation(this);}; 
	this.iNext.onclick = function() { this.owner.pageNavigation(this);}; 
	this.iLast.onclick = function() { this.owner.pageNavigation(this);}; 
	this.sPageList.onchange = function() { this.owner.pageNavigation(this);}; 

	paginationSpan.appendChild(this.iFirst);
	paginationSpan.appendChild(this.iPrev);
	paginationSpan.appendChild(this.sPageList);
	paginationSpan.appendChild(this.sPageText);
	paginationSpan.appendChild(this.iNext);
	paginationSpan.appendChild(this.iLast);
	return paginationSpan;
};
//------------------------------------------------------------------------------
myTable.prototype.createSpan = function(id,className,width,title,text){
	var span = document.createElement('span');
	this.setClass(span,className);
	span.id = id;
	span.width = width;
	span.title = title;
	span.innerHTML=text;
	return span;
};
//------------------------------------------------------------------------------
myTable.prototype.createImage = function(src,id,width,title){
	var img = document.createElement('img');
	img.src = src
	img.id = id;
	img.width = width
	img.title = title;
	return img;
};

//------------------------------------------------------------------------------
myTable.prototype.createSelect = function(id,data){
	var select = document.createElement('select');
	select.id=id;
	for (var x=0; x<data.length ; x++){ 
		opt = document.createElement('option');
		opt.text = data[x][0];
		opt.value = data[x][1];
		try {
			select.add(opt, null); // standards compliant; doesn't work in IE
		} catch(ex) {
			select.add(opt); // IE only
		}

	}
	return select;
};

//------------------------------------------------------------------------------
myTable.prototype.createTable = function(id,className,cellPadding,cellSpacing,width,height,border){
	var table = document.createElement('table');
	if (id != 'undefined' || id != null) table.id = id;
	if (className != 'undefined' || className != null) table.className = className;
	if (border != 'undefined' || border != null) table.border = border;
	if (cellSpacing != 'undefined' || cellSpacing != null) table.cellSpacing = cellSpacing;
	if (cellPadding != 'undefined' || cellPadding != null) table.cellPadding = cellPadding;
	if (width != 'undefined' || width != null) table.width = width;
	if (height != 'undefined' || height != null) table.height = height;
	return table;
};

//------------------------------------------------------------------------------
myTable.prototype.setPaginationElementText = function(tag,id,value){
	var spanList = this.tableFooterPagination.getElementsByTagName(tag);
	for (var x=0;x<spanList.length ; x++){
		if (spanList[x].id == id){
			spanList[x].innerHTML = value;
			break;
		}
	}
};

//------------------------------------------------------------------------------
myTable.prototype.showFilterPopup = function (el){
	var elPos = getPos(el.offsetParent);
	var lbs = this.filterPopup.getElementsByTagName('label');
	var ip = this.filterPopup.getElementsByTagName('input')[0];
	var divTag = this.filterPopup.getElementsByTagName('div');
	for (x=0;x<divTag.length ;x++ ){
		if(divTag[x].id=='reset') btReset = divTag[x]; 
		if(divTag[x].id=='cancel') btCancel = divTag[x]; 
		if(divTag[x].id=='apply') btApply = divTag[x]; 
	}

	btReset.onmouseover = function(){this.owner.setClass(this,'filterButtonover')} 
	btReset.onmouseout = function(){this.owner.setClass(this,'filterButton')} 
	btCancel.onmouseover = function(){this.owner.setClass(this,'filterButtonover')} 
	btCancel.onmouseout = function(){this.owner.setClass(this,'filterButton')} 
	btApply.onmouseover = function(){this.owner.setClass(this,'filterButtonover')} 
	btApply.onmouseout = function(){this.owner.setClass(this,'filterButton')} 
	
	var fld = el.scope.split(';')
	var inputType = fld[0].substr(0,1);

	ip.style.width = el.offsetParent.offsetWidth * .7;
	lbs[0].innerHTML = fld[1] ;
	var selTag = this.filterPopup.getElementsByTagName('select')[0];

	if(inputType=='T'){
		selTag.options[0] = new Option('Starting','S');
		selTag.options[1] = new Option('Ending','E');
		selTag.options[2] = new Option('Contain','C');
	} else {
		selTag.options[0] = new Option('Greater than','G');
		selTag.options[1] = new Option('Less than','L');
		selTag.options[2] = new Option('Equals','Q');
	}	

	this.filterPopup.style.display='block';
	this.filterPopup.style.top = elPos.y+25; 
	this.filterPopup.style.left = elPos.x;
	this.filterPopup.style.width = lbs[0].offsetWidth + 20 + selTag.offsetWidth + 20 + ip.offsetWidth  ; 

	ip.value = this.filterInput;
	ip.focus();
	btReset.owner = btCancel.owner = btApply.owner = this;

	btReset.onclick = function(){ ip.value="";this.owner.resetFilter(el)};
	btCancel.onclick = function(){ ip.value="";this.owner.cancelFilter()};
	btApply.onclick = function(){ this.owner.filterData(el,ip.value,selTag.value)};

};
//------------------------------------------------------------------------------

myTable.prototype.filterData = function(flterIcon,value,chkType){
	var fldType = flterIcon.scope.split(';')[0].substr(0,1)
	this.filterInput = value;
	this.noOfRows = this.dataArray.length;
	this.noOfFilteredRows=0;
	this.hideFilterPopup();
	this.tRows = new Array()
	if (value.length > 0){
		this.resetFilterIcons(flterIcon);
		flterIcon.className = 'filterActive'
		for (x=0;x<this.noOfRows ;x++ )	{
			var colData = this.dataArray[x][parseInt(flterIcon.id)]
			if (fldType=='T')	{
				if ((chkType=='C' && colData.indexOf(value) >= 0 ) || (chkType=='S' && colData.left(value.length)== value ) || (chkType=='E' && colData.right(value.length)== value )){
					this.tRows[this.tRows.length] = this.dataArray[x]
				}
			}else if(fldType=='N'){
				if ((chkType =='G' && colData > value) || (chkType =='L' && colData < value) || (chkType =='Q' && colData == value)){
					this.tRows[this.tRows.length] = this.dataArray[x]
				}
			}else if(fldType=='D'){
				if ((chkType =='G' && toDate(colData) > toDate(value)) || (chkType =='L' && toDate(colData) < toDate(value)) || (chkType =='Q' && toDate(colData) == toDate(value))){
					this.tRows[this.tRows.length] = this.dataArray[x]
				}
			}
		}
		this.updateControlForFilters()
		this.updateDataTable(0);
	}else {
		this.resetFilter(flterIcon);
	}
	if (this.tType == 'P'){ this.setCurrentPageNo(1); }
};
//------------------------------------------------------------------------------
myTable.prototype.updateControlForFilters = function(){
	this.noOfFilteredRows = this.tRows.length;
	this.setTableHeight() 
	if(this.tType == 'P' && this.noOfPages > 1){
		this.sPageList.length = this.noOfPages
		for (var x=0; x<this.noOfPages ; x++){ this.sPageList.options[x] = new Option(x+1,x+1); }
		this.setCurrentPageNo(1);
		this.sPageText.innerHTML = '&nbsp;'+this.ofText +'&nbsp;<span id="noofpages">'+this.noOfPages+'</span>&nbsp;'+ this.pageText
	}	
};
//------------------------------------------------------------------------------
myTable.prototype.resetFilterIcons = function(el){
	var heading = el.offsetParent.offsetParent;
	var filters = heading.getElementsByTagName('div');
	for (x=0;x<filters.length ;x++ ){
		if (filters[x].className.indexOf('filter') >= 0){ filters[x].className = 'filter'; }
	}
};
//------------------------------------------------------------------------------
myTable.prototype.resetFilter = function(cancelIcon){
	this.filterInput="";
	this.resetFilterIcons(cancelIcon);
	this.hideFilterPopup();
	this.noOfFilteredRows=this.dataArray.length;
	this.tRows = this.dataArray;
	this.updateControlForFilters()
	if (this.tType == 'P'){ this.setCurrentPageNo(1); }
	this.updateDataTable(0);
};
//------------------------------------------------------------------------------
myTable.prototype.cancelFilter = function(){
	this.hideFilterPopup();
};
//------------------------------------------------------------------------------
myTable.prototype.hideFilterPopup = function(){
	this.filterPopup.style.display='none';
};
//------------------------------------------------------------------------------
myTable.prototype.sortData = function(el){
	this.hideFilterPopup();
	if(el.className  == 'sortable-asc'){
		this.tRows.reverse() ;
		el.className  = 'sortable-desc'
	}else if (el.className  == 'sortable-desc'){
		this.tRows.reverse() ;
		el.className  = 'sortable-asc';
	}else {
		this.tRows.sort(function (a,b){
				if ( el.scope.toUpperCase() =='NUMERIC' ){
					var v1 = parseFloat(a[el.id]);
					var v2 = parseFloat(b[el.id])
				}else if(el.scope.toUpperCase() =='TEXT'){
					var v1 = a[el.id];
					var v2 = b[el.id];
				}else if (el.scope.toUpperCase() == 'DATE'){
					var v1 = toDate(a[el.id],myTableMonths);
					var v2 = toDate(b[el.id],myTableMonths);
				}
				if ( v1 < v2 ) return -1;
				else if (v1 > v2 ) return 1;
				else return 0;
			}
		);
		el.className  = 'sortable-asc'
	}
	var pNode = this.tableHeading.getElementsByTagName('div');
	for (j=0;j<pNode.length ;j++ ){
		if (pNode[j].id != el.id && pNode[j].className.indexOf('sortable-') >= 0) {	pNode[j].className = 'sortable' ;}
	}
	this.updateDataTable(0);
	if (this.tType == 'P'){
		this.setCurrentPageNo(1);
	}
};
//------------------------------------------------------------------------------
myTable.prototype.updateDataTable = function(rowPos){
	this.showLoader()
	this.hideFilterPopup();
	if (this.tType == 'P' && this.noOfPages > 1) { 
		this.setPaginationElementText('span',"nooffilteredrows",this.noOfFilteredRows);
		this.setPaginationElementText('span',"nooftotalrows",this.noOfRows);
		this.sRowsList.options[this.sRowsList.length-1].value=this.noOfRows
	}
	var obody = this.tableRows.tBodies[0];
	var tbody = this.createDataRows(rowPos)
	this.tableRows.removeChild(obody);
	this.tableRows.appendChild(tbody);
	this.hideLoader()
};
//----------------------------------------------------------------------------
myTable.prototype.addRow = function(row){
	this.tRows.push(row);
	this.setTableHeight();
	this.setPageOptionList();
	this.updateControlForFilters();
	this.setCurrentPageNo(this.noOfPages);
	var firstRow = (this.noOfPages * this.noOfRowsPerPage ) - this.noOfRowsPerPage;
	this.updateDataTable(firstRow);
	
};

//----------------------------------------------------------------------------
myTable.prototype.removeLastRow = function(){
	if (this.tRows.length <= 1){ return; }
	this.tRows.pop();
	this.setTableHeight();
	this.setPageOptionList();
	this.updateControlForFilters();
	this.setCurrentPageNo(this.noOfPages);
	var firstRow = (this.noOfPages * this.noOfRowsPerPage ) - this.noOfRowsPerPage;
	this.updateDataTable(firstRow);
	
};
//------------------------------------------------------------------------------
myTable.prototype.setPageOptionList = function(){
	if(this.tType == 'P'){
		var currPage = this.tableFooterPagination.getElementsByTagName('select')[1];
		currPage.length = 0;
		for (var x=0;x<this.noOfPages ; x++) {currPage.options[x] = new Option(x+1,x+1);}
	}
};
//------------------------------------------------------------------------------
myTable.prototype.getCurrentPageNo = function(){
	var currPage = this.tableFooterPagination.getElementsByTagName('select')[1];
	return parseInt(currPage.value);
};
//------------------------------------------------------------------------------
myTable.prototype.setCurrentPageNo = function(n){
	if (this.tType == 'P' && this.noOfPages > 1){
		var currPage = this.tableFooterPagination.getElementsByTagName('select')[1];
		currPage.value = n;
	}
};
//------------------------------------------------------------------------------
myTable.prototype.pageNavigation = function (el){
	var cPageNo = this.getCurrentPageNo();
	switch(el.id)
		{
			case 'firstpage':   if (cPageNo == 1) return; cPageNo = 1;	break;
			case 'prevpage':    if (cPageNo == 1) return; cPageNo --; 	break;
			case 'nextpage':    if (cPageNo == this.noOfPages) return; cPageNo ++; break;
			case 'lastpage':    if (cPageNo == this.noOfPages) return; cPageNo = this.noOfPages; break;
			case 'selectrows':  this.noOfRowsPerPage = (parseInt(el.value)) ;
								this.setTableHeight();
								this.setPageOptionList();
								this.setPaginationElementText('span',"noofpages",this.noOfPages);
								cPageNo = 1;
								break;
		}
	this.setCurrentPageNo(cPageNo);
	var firstRow = (cPageNo * this.noOfRowsPerPage ) - this.noOfRowsPerPage;
	this.updateDataTable(firstRow)
};
//------------------------------------------------------------------------------
myTable.prototype.createEmptyRow = function(){
	var _emptyROw = new Array();
	for (var m=0;m<this.noOfCols ;m++ ) {_emptyROw[m] = "&nbsp;";}
	return _emptyROw;
};
//------------------------------------------------------------------------------
myTable.prototype.setClass = function (element,className){
	element.setAttribute('class',className);
	element.setAttribute('className',className); //<iehack>
};
//------------------------------------------------------------------------------
myTable.prototype.getBrowser = function(){
	var browser=navigator.appName;
	var ns=false;
	var ms=false;
	if (browser == 'Microsoft Internet Explorer') {ms=true;}
	if (browser == 'Netscape') {ns=true;}
	return {'ms':ms,'ns':ns}
};
//------------------------------------------------------------------------------
function allTrim(s){
	if (typeof(s)=='string') {s = s.replace(/^\s*/, "").replace(/\s*$/, "");}
	return s;
}
//------------------------------------------------------------------------------
function getPos(obj)
 {
   var pos = {x: obj.offsetLeft||0, y: obj.offsetTop||0};
    while(obj = obj.offsetParent) {
       pos.x += obj.offsetLeft||0;
       pos.y += obj.offsetTop||0;
    }
    return pos;
}
//------------------------------------------------------------------------------
// to get left side string as per length
String.prototype.left = function (x){
	return this.substr(0,x);
}
//------------------------------------------------------------------------------
// to get right side string as per length
String.prototype.right = function (x){
	return this.substr(this.length-x,x);
}