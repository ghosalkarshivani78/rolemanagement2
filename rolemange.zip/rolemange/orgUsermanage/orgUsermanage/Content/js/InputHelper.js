﻿function isNumberOrDecimalKey(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode;
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    } else {
        return true;
    }
}

function isNumberKey(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    } else {
        return true;
    }
}

/*
this function is accepting integer and decimal numbers
without - and + symbol
*/
function isNumberWithoutSymbol(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode;
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {

        if (charCode == 43 || charCode == 45) {
            return false;
        }
        else {
            return false;
        }
    } else {
        return true;
    }
}

//function isNumberWithoutDecimal(evt) {
//    var charCode = (evt.which) ? evt.which : event.keyCode;
//    if (charCode > 31 && (charCode < 48 || charCode > 57)) {

//        if (charCode == 43 || charCode == 45 || charCode == 46) {
//            return false;
//        }
//        return false;
//    } 
//    else {
//        return true;
//    }
//}

//function onlyAlphabets(e, t) {

//    try {

//        if (window.event) {
//            var charCode = window.event.keyCode;
//        }
//        else if (e) {
//            var charCode = e.which;
//        }
//        else { return true; }
//        if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123))
//            return true;
//        else
//            return false;
//    }
//    catch (err) {

//        alert(err.Description);
//    }
//} 