﻿function GetAirTicketModel() {
    var objAirTicket = {};
    objAirTicket.BillNo = $("#BillNo").val();
    objAirTicket.Open = $("#Open").val();
    objAirTicket.CreditLimit = $("#CreditLimit").val();
    objAirTicket.AmountDue = $("#AmountDue").val();
    objAirTicket.Date = $("#Date").val();
    objAirTicket.fromPSR = $("#fromPSR").val();
    objAirTicket.toPSR = $("#toPSR").val();
    objAirTicket.Conj = $("#Conj").val();
    objAirTicket.PNRno = $("#PNRno").val();
    objAirTicket.Airln1 = $("#Airln1").val();
    objAirTicket.Airln2 = $("#Airln2").val();
    objAirTicket.Airln3 = $("#Airln3").val();
    objAirTicket.Airln4 = $("#Airln4").val();
    objAirTicket.IsBSP = $("#IsBSP").val();
    objAirTicket.TicketFlightNo = $("#TicketFlightNo").val();
    objAirTicket.PassFlightNo = $("#PassFlightNo").val();
    objAirTicket.fromTicketTravelDate = $("#fromTicketTravelDate").val();
    objAirTicket.toTicketTravelDate = $("#toTicketTravelDate").val();
    objAirTicket.fromPassTravelDate = $("#fromPassTravelDate").val();
    objAirTicket.toPassTravelDate = $("#toPassTravelDate").val();
    objAirTicket.NoOfTicket = $("#NoOfTicket").val();
    objAirTicket.IsPosted = $("#IsPosted").val();
    objAirTicket.IsVoid = $("#IsVoid").val();
    objAirTicket.Sector = $("#Sector").val();
    objAirTicket.PassengerType = $("#PassengerType").val();
    objAirTicket.Class = $("#Class").val();
    objAirTicket.Fare = $("#Fare").val();
    objAirTicket.Tax = $("#Tax").val();
    objAirTicket.Insurn = $("#Insurn").val();
    objAirTicket.VoidAmt = $("#VoidAmt").val();
    objAirTicket.SerChg = $("#SerChg").val();
    objAirTicket.OCTax = $("#OCTax").val();
    objAirTicket.IST = $("#IST").val();
    objAirTicket.EdiCess = $("#EdiCess").val();
    objAirTicket.Currency = $("#Currency").val();
    objAirTicket.ROE = $("#ROE").val();
    objAirTicket.DollarAmt = $("#DollarAmt").val();
    objAirTicket.DollarPSF = $("#DollarPSF").val();
    objAirTicket.DollarATT = $("#DollarATT").val();
    objAirTicket.DollarInsur = $("#DollarInsur").val();
    objAirTicket.ServiceTax = $("#ServiceTax").val();
    objAirTicket.ManageFee = $("#ManageFee").val();
    objAirTicket.FareBasis = $("#FareBasis").val();
    objAirTicket.Title = $("#Title").val();
    objAirTicket.Passenger = $("#Passenger").val();
    objAirTicket.ORAmt = $("#ORAmt").val();
    objAirTicket.CCComm = $("#CCComm").val();
    objAirTicket.BillAmt = $("#BillAmt").val();
    objAirTicket.DiscNill = $("#DiscNill").val();
    objAirTicket.TDS = $("#TDS").val();
    objAirTicket.NetAmt = $("#NetAmt").val();
    objAirTicket.TktFare = $("#TktFare").val();
    objAirTicket.CNNumber = $("#CNNumber").val();
    objAirTicket.CNDate = $("#CNDate").val();
    objAirTicket.TotalAmount = $("#TotalAmount").val();
    objAirTicket.CstAmount = $("#CstAmount").val();
    objAirTicket.SChargeAmt = $("#SChargeAmt").val();
    objAirTicket.TDSAmount = $("#TDSAmount").val();
    objAirTicket.NetRefund = $("#NetRefund").val();
    objAirTicket.ABUnknown = $("#ABUnknown").val();
    objAirTicket.CCSettlement = $("#CCSettlement").val();
    objAirTicket.NoCNAllowed = $("#NoCNAllowed").val();
    objAirTicket.CreditCCNo = $("#CreditCCNo").val();
    objAirTicket.MCO = $("#MCO").val();
    objAirTicket.PTA = $("#PTA").val();
    objAirTicket.VisaPPT = $("#VisaPPT").val();
    objAirTicket.EFC = $("#EFC").val();
    objAirTicket.EFCTax = $("#EFCTax").val();
    objAirTicket.DomInt = $("#DomInt").val();
    objAirTicket.FromFlightNo = $("#FromFlightNo").val();
    objAirTicket.ToFlightNo = $("#ToFlightNo").val();
    objAirTicket.SelectedPaymentMode = $("#SelectedPaymentMode").val();
    objAirTicket.IsPaid = $("#IsPaid").is(":checked");
    objAirTicket.selectedVendor = $("#selectedVendor").val();
    return objAirTicket;
}

function validateBeforeTicketSave() {
    if ($("#Fare").val() == "") {
        alert("Enter Fare amount");
        return false;
    }
    else if ($("#FareBasis").val().length > 1) {
        alert("fare basis cannot be more than 1 character");
        return false;
    }
    else if ($("#CreditCCNo").val().length > 2) {
        alert("CreditCCNo cannot be more than 2 characters");
        return false;
    }
    else if ($("#AirlnCode").val().length > 2) {
        alert("Code cannot be more than 2 characters");
        $('#AirlnCode').focus();
        return false;
    }
    else {
        return true;
    }


}
