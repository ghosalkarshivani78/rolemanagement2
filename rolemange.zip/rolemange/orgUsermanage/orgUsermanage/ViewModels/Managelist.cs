﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using orgUsermanage.Controllers.ViewModels;

namespace orgUsermanage.Controllers.ViewModels
{
    public class Managelist
    {
        public int id { get; set; }
        public string role { get; set; }
        public string description { get; set; }

        public string modulename { get; set; }
        public bool add { get; set; }
        public bool edit { get; set; }
        public bool delete { get; set; }

        public string useraccessid { get; set; }

        public int usersid { get; set; }
    }
}