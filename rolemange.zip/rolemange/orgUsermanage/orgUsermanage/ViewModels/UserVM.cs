﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using orgUsermanage.Query;

namespace orgUsermanage.Controllers.ViewModels
{
    public class UserVM
    {
      
        public int usersid { get; set; }
        public string user_name { get; set; }
        public string email { get; set; }
        public string phone { get; set; }
        public string password { get; set; }
        public string orgid { get; set; }
        public DateTime created_date { get; set; }
        public string created_By { get; set; }
        public DateTime modified_date { get; set; }
        public string roleid { get; set; }
        public SelectList Organization { get; set; }


        public string modulename { get; set; }
        public bool add { get; set; }
        public bool edit { get; set; }
        public bool delete { get; set; }

        public bool Flag { get; set; }

        public SelectList roles { get; set; }

        public List<System.Web.Mvc.SelectListItem> orglist { get; set; }
        //public users checkuser(string Email, string password)
        //{
       
        //    //IUserQuery objIUserQuery;
        //    //objIUserQuery = new UserQuery();
        //    var check = objIUserQuery.checkuser(Email, password);
        //    return check;
        //}


        public List<UserVM> getuserlist(IUserQuery qry, int userid)
        {
            AllAccessVM accessvm = new AllAccessVM();
            List<UserVM> li = new List<UserVM>();
          //  var result = qry.userlist();
            var res = qry.checkuserByidlist(userid);

           var check = qry.checkuserByid(userid);
           if (check.Flag == true)
           {
               var r = getfulluserlist(qry);
               return r;
           }

           else
           {

               foreach (var i in res)
               {
                   UserVM u = new UserVM();

                   u.usersid = i.usersid;
                   u.user_name = i.user_name;
                   u.email = i.user_email;
                   u.password = i.password;
                   u.phone = i.phone;
                   u.created_date = i.created_date;
                   u.orgid = qry.orglist().Where(x => x.org_id == i.org_id).SingleOrDefault().org_name;
                   u.roleid = qry.useraccessslist().Where(x => x.id == i.roleid).SingleOrDefault().role;

                   //var access = qry.useraccessslist().Where(x => x.id == i.roleid).SingleOrDefault();
                   var user = qry.userlist().Where(x => x.usersid == userid).SingleOrDefault();
                   var access = qry.useraccessslist().Where(x => x.id == user.roleid).SingleOrDefault();

                   AllAccessVM accvm = new AllAccessVM();
                   accvm.add = qry.useraccessscreenlist().Where(x => x.useraccesssid == access.id && x.modulename == "User").SingleOrDefault().adddata;

                   //u.add = qry.useraccessscreenlist().Where(x => x.useraccesssid == access.id && x.modulename == "User").SingleOrDefault().adddata;

                   u.edit = qry.useraccessscreenlist().Where(x => x.useraccesssid == access.id && x.modulename == "User").SingleOrDefault().editdata;

                   u.delete = qry.useraccessscreenlist().Where(x => x.useraccesssid == access.id && x.modulename == "User").SingleOrDefault().deletedata;


                   u.modified_date = i.modified_date;
                   li.Add(u);
               }

               return li;
           }

        }


        public List<UserVM> getfulluserlist(IUserQuery qry) 
        {
            List<UserVM> li = new List<UserVM>();
            var result = qry.userlist();
            foreach (var i in result) 
            {
                UserVM u = new UserVM();
                u.usersid = i.usersid;
                u.user_name = i.user_name;
                u.email = i.user_email;
                u.password = i.password;
                u.phone = i.phone;
                u.created_date = i.created_date;
                u.orgid = qry.orglist().Where(x => x.org_id == i.org_id).SingleOrDefault().org_name;
                u.roleid = qry.useraccessslist().Where(x => x.id == i.roleid).SingleOrDefault().role;

                u.add = true;
                u.edit = true;
                u.delete = true;
                li.Add(u);
            }
            return li;
        }

       

    }

 
}