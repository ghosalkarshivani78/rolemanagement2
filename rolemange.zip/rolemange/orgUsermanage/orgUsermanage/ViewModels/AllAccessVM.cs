﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using orgUsermanage.Controllers.ViewModels;
using orgUsermanage.Query;

namespace orgUsermanage.Controllers.ViewModels
{
    public class AllAccessVM
    {

        public string modulename  { get; set; }
        public bool add  { get; set; }
        public bool edit { get; set; }
        public bool delete { get; set; }

        public List<UserVM> uservmlist = new List<UserVM>();
        public List<OrgVM> orgvmlist = new List<OrgVM>();
        public List<Managelist> mangevmlist = new List<Managelist>();


       
    }
}