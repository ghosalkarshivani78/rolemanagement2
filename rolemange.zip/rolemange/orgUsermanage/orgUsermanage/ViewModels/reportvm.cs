﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace orgUsermanage.Controllers.ViewModels
{
    public class reportvm
    {

        public int userid { get; set; }
        public string user_name { get; set; }
        public string user_email { get; set; }
        public string phone { get; set; }
        public string password { get; set; }
        public string org_id { get; set; }
        public DateTime created_date { get; set; }
        public string roleid { get; set; }


        public class managereport
        {

            public int id { get; set; }
            public string role { get; set; }
            public string modulename { get; set; }
            public string usersid { get; set; }
            public string password { get; set; }
            public string useraccesssid { get; set; }
            public string description { get; set; }
        }
 
    }
}