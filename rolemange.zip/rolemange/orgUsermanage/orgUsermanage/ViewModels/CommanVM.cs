﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace orgUsermanage.Controllers.ViewModels
{
    public class CommanVM
    {
       

        public UserVM objuserVM { get; set; }
        public OrgVM objorgVM { get; set; }

        public CommanVM() {
            objuserVM = new UserVM();
            objorgVM = new OrgVM();
        
        }


        

    }
    
}