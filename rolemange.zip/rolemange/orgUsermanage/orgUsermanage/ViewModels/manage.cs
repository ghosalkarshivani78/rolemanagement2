﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using orgUsermanage.Query;

namespace orgUsermanage.Controllers.ViewModels
{
    public class manage
    {
        public int id { get; set; }
        public string role { get; set; }
        public string description { get; set; }

        public bool useraccessadd { get; set; }
        public bool useraccessedit { get; set; }
        public bool useraccessdelete { get; set; }

        public bool orgaccessadd { get; set; }
        public bool orgaccessedit { get; set; }
        public bool orgaccessdelete { get; set; }

        public bool manageaccessadd { get; set; }
        public bool manageaccessedit { get; set; }
        public bool manageaccessdelete { get; set; }

        public string User { get; set; }

        public string organization { get; set; }

        public string UserManage { get; set; }

        //public bool usercheck { get; set; }



        public string useraccesssid { get; set; }

        public string usersid { get; set; }
        public string modulename { get; set; }
        public bool add { get; set; }
        public bool edit { get; set; }
        public bool delete { get; set; }


        public List<manage> getmanagelist(IUserQuery qry, int userid)
        {
                manage managevm = new manage();

                List<manage> mangeli = new List<manage>();
                var manage = qry.userlist().Where(x => x.usersid == Convert.ToInt32(userid)).SingleOrDefault();
                

                if (manage.Flag == true)
                {
                    var userlist = getfullmanagelist(qry);
                    return userlist;
                }
                else 
                {
                    var check = qry.useraccessslist().Where(x => x.id == manage.roleid).SingleOrDefault();
                    managevm.role = check.role;
                    managevm.description = check.description;
                    managevm.useraccesssid = check.id.ToString();
                    managevm.usersid = manage.usersid.ToString();
                    managevm.add = qry.useraccessscreenlist().Where(x => x.useraccesssid == check.id && x.modulename == "UserManage").SingleOrDefault().adddata;
                    managevm.edit = qry.useraccessscreenlist().Where(x => x.useraccesssid == check.id && x.modulename == "UserManage").SingleOrDefault().editdata;
                    managevm.delete = qry.useraccessscreenlist().Where(x => x.useraccesssid == check.id && x.modulename == "UserManage").SingleOrDefault().deletedata;
                    managevm.role = check.role;
                    managevm.description = check.description;
                    managevm.useraccesssid = check.id.ToString();
                    managevm.usersid = manage.usersid.ToString();
                    managevm.modulename = check.role; ;
                    mangeli.Add(managevm);
                    return mangeli;
                }
               

        }

        public List<manage> getfullmanagelist(IUserQuery qry)
        {
            List<manage> li = new List<manage>();
            
                 var useaccess = qry.useraccessslist();
                 var useraccessscreen = qry.useraccessscreenlist();
                 var result = (from a in useraccessscreen
                              join
                              s in useaccess on a.useraccesssid equals s.id
                              select new
                              {
                                  a.id,
                                  a.modulename,
                                  a.adddata,
                                  a.editdata,
                                  a.deletedata,
                                  a.useraccesssid,
                                  a.usersid,
                                  s.role,
                                  s.description
                              }).ToList();

            foreach (var i in result) 
            {
                manage m = new manage();
                m.id = i.id;
                m.role = i.role;
                m.description = i.description;
                m.modulename = i.modulename;
                m.add = true;
                m.edit = true;
                m.delete = true;
                m.useraccesssid = i.useraccesssid.ToString();
                m.usersid = i.usersid.ToString();
                li.Add(m);
            }
            return li;
        }
    }
}