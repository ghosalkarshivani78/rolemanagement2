﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using orgUsermanage.Query;
using orgUsermanage.Models;

namespace orgUsermanage.Controllers.ViewModels
{
    public class forgotpassVM
    {
        public string email { get; set; }
        public string password { get; set;}
        public string newpassword { get; set; }
        public string confirmpass { get; set; }

    }
}