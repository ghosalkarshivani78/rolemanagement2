﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using orgUsermanage.Query;

namespace orgUsermanage.Controllers.ViewModels
{
    public class OrgVM
    {
        public int org_id { get; set; }
        public string org_name { get; set; }
        public string org_address { get; set; }
        public string org_email { get; set; }
        public string phone { get; set; }
        public DateTime created_date { get; set; }
        public string created_By { get; set; }
        public DateTime modified_date { get; set; }



        public string modulename { get; set; }
        public bool add { get; set; }
        public bool edit { get; set; }
        public bool delete { get; set; }


        public List<OrgVM> getorglist(IUserQuery qry,int userid) 
        {
            List<OrgVM> li = new List<OrgVM>();
            //var result = qry.orglist();
           

            var access = qry.checkuserByid(userid);

            var result = qry.orglist().Where(x=>x.org_id == access.org_id);

            var screen = qry.useraccessscreenlist();

            if (access.Flag == true) 
            {
               var o = getfullorglist(qry);
               return o;
            }

            
            foreach (var i in result)
            {
                OrgVM o = new OrgVM();
                o.org_id = i.org_id;
                o.org_name = i.org_name;
                o.org_email = i.org_email;
                o.phone = i.phone;
                o.org_address = i.org_address;
                o.created_date = i.created_date;


                AllAccessVM accvm = new AllAccessVM();
                accvm.add = qry.useraccessscreenlist().Where(x => x.useraccesssid == access.roleid && x.modulename == "Organization").SingleOrDefault().adddata;

                //o.add = qry.useraccessscreenlist().Where(x => x.useraccesssid == access.roleid && x.modulename == "Organization").SingleOrDefault().adddata;
                o.edit = qry.useraccessscreenlist().Where(x => x.useraccesssid == access.roleid && x.modulename == "Organization").SingleOrDefault().editdata;
                o.delete = qry.useraccessscreenlist().Where(x => x.useraccesssid == access.roleid && x.modulename == "Organization").SingleOrDefault().deletedata;
                li.Add(o);
            }
            return li;
        }

        public List<OrgVM> getfullorglist(IUserQuery qry) 
        {
            List<OrgVM> li = new List<OrgVM>();
            var check = qry.orglist();

            foreach(var i in check)
            {
                OrgVM o = new OrgVM();
                o.org_id = i.org_id;
                o.org_name = i.org_name;
                o.org_email = i.org_email;
                o.phone = i.phone;
                o.org_address = i.org_address;
                o.created_date = i.created_date;
                o.add = true;
                o.edit = true;
                o.delete = true;
                li.Add(o);
            }
            return li;
        }
    }
}