﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using orgUsermanage.Models;

namespace orgUsermanage.Query
{
   public interface IUserQuery
    {
       List<users> userlist();
       List<org> orglist();
       List<useraccesss> useraccessslist();
       List<useraccessscreen> useraccessscreenlist();
       users checkuser(string Email, string password);
       void saveuser(users u);
       users checkuserByEmail(string email);
       void saveorg(org org);
       org checkorgByEmail(string org_email);
       users checkuserByid(int usersid);
       void updateUserdata(users u);
       org checkOrgByid(int org_id);
       void updateOrgData(org org);
       users deleteuserdata(int usersid);
       void deleteuser(users u);
       org deleteorgdata(int org_id);
      void deleteorg(org org);
      void saveuseraccess(useraccesss u);
      void savescreen(useraccessscreen s);
      List<users> checkuserByidlist(int userid);
      void updatemanagedata(useraccessscreen u);
      void deletescreen(useraccessscreen u);
      void updateuseraccess(useraccesss u);
      void deleteaccess(int useraccesssid);
      void updateuserpass(users u); 
    }
}
