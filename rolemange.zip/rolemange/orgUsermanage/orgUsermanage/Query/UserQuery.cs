﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NHibernate;
using orgUsermanage.Models;

namespace orgUsermanage.Query
{
    public class UserQuery: IUserQuery
    {
 
        private ISession session;

        public UserQuery() 
        {
            session = NhibernateSession.OpenSession();
        }

        public List<users> userlist() 
        {
            var list = session.QueryOver<users>().List().ToList();
            return list;
        }

        public List<org> orglist() 
        {
            var list = session.QueryOver<org>().List().ToList();
            return list;
        
        }

        public List<useraccesss> useraccessslist() {
            var list = session.QueryOver<useraccesss>().List().ToList();
            return list;
        }

        public List<useraccessscreen> useraccessscreenlist()
        {
            var list = session.QueryOver<useraccessscreen>().List().ToList();
            return list;
        }

        public users checkuser(string Email,string password) 
        {
            var result = session.QueryOver<users>().Where(x => x.user_email == Email && x.password == password).SingleOrDefault();
            return result;
        }

        public void saveuser(users u) 
        {
            session.Save(u);
            session.Flush();
            session.Close();
        }

        public users checkuserByEmail(string email)
        {
            var check = session.QueryOver<users>().Where(x => x.user_email == email).SingleOrDefault();
            return check;
        }

        public void saveorg(org org)
        {
            session.Save(org);
            session.Flush();

        }

       public org checkorgByEmail(string org_email)
        {
            var result = session.QueryOver<org>().Where(x => x.org_email == org_email).SingleOrDefault();
            return result;

        }

        public users checkuserByid(int usersid)
        {
            var result = session.QueryOver<users>().Where(x =>x.usersid == usersid).SingleOrDefault();
            return result;
        }

        public void updateUserdata(users u) 
        {
            session.SaveOrUpdate(u);
            session.Flush();
            session.Close();
        }

        public org checkOrgByid(int org_id)
        {
            var result = session.QueryOver<org>().Where(x => x.org_id == org_id).SingleOrDefault();
            return result;
        }

        public void updateOrgData(org org)
        {
            session.SaveOrUpdate(org);
            session.Flush();
        }

        public users deleteuserdata(int usersid)
        {
            var result = session.QueryOver<users>().Where(x => x.usersid == usersid).SingleOrDefault();
            return result;
        }

        public void deleteuser(users u)
        {
            session.Delete(u);
            session.Flush();
        }

        public org deleteorgdata(int org_id) 
        {
            var result = session.QueryOver<org>().Where(x => x.org_id == org_id).SingleOrDefault();
            return result;
        }

        public void deleteorg(org org) 
        {
            session.Delete(org);
            session.Flush();
        }

        public void saveuseraccess(useraccesss u)
        {
            session.Save(u);
            session.Flush();
        }

        public void savescreen(useraccessscreen s) 
        {
            session.Save(s);
            session.Flush();
        }

        public List<users> checkuserByidlist(int userid) 
        {
            var list = session.QueryOver<users>().Where(x => x.usersid == userid).List().ToList();
            return list;
        }

        public void updatemanagedata(useraccessscreen u) 
        {
            session.SaveOrUpdate(u);
            session.Flush();
        }



        public void deletescreen(useraccessscreen u) 
        {
            session.Delete(u);
            session.Flush();
        }


        public void updateuseraccess(useraccesss u)
        {
            session.SaveOrUpdate(u);
            session.Flush();
        }

        public void deleteaccess(int useraccesssid )
        {
            var r = session.QueryOver<useraccesss>().Where(x => x.id == useraccesssid).SingleOrDefault();
            session.Delete(r);
            session.Flush();
        }

        public void updateuserpass(users u)
        {
            session.SaveOrUpdate(u);
            session.Flush();

                //using (var transaction = session.BeginTransaction())
                //{
                //    session.SaveOrUpdate(u);
                //    transaction.Commit();
                //}
        }
    }
}