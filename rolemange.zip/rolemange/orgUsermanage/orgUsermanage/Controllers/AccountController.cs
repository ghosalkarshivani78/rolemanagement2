﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using orgUsermanage.Query;
using orgUsermanage.Models;
using System.IO;
using System.Data;
using orgUsermanage.Controllers.ViewModels.DataTable;
using orgUsermanage.Controllers.ViewModels;
using Microsoft.Reporting.WebForms;


namespace orgUsermanage.Controllers
{
    public class AccountController : Controller
    {

        IUserQuery ui;

        public ActionResult Index()
        {
            CommanVM cvm = new CommanVM();
            return View(cvm);
        }

        public ActionResult forgotpassword() 
        {
            forgotpassVM u = new forgotpassVM();
            return View(u);
        }

        //[HttpPost]
        //public ActionResult forgotpassword(forgotpassVM u)
        //{
        //    IUserQuery objIUserQuery;
        //    objIUserQuery = new UserQuery();

        //   var result = objIUserQuery.userlist().Where(x => x.user_email == u.email).SingleOrDefault();
        //   if (result != null)
        //   {
        //       u.password = result.password;
        //   }
        //   else 
        //   {
        //       ViewBag.Message = "Invalid Email";
        //   } 

        //    return View("forgotpassword", u);
        //}


        [HttpPost]
        public ActionResult forgotpassword(forgotpassVM u) 
        {
            IUserQuery objIUserQuery;
            objIUserQuery = new UserQuery();

            var result = objIUserQuery.userlist().Where(x => x.user_email == u.email).SingleOrDefault();
            Session["UserEmail"]=result.user_email;
            if (result == null)
            {
                ViewBag.Message = "Invalid Email";
            }
            //if (result != null)
            //{
            //    u.password = result.password;
            //}
            //else
            //{
            //    ViewBag.Message = "Invalid Email";
            //}

            //return View("forgotpassword", u);
            return View("ResetPassword",u);
        }


        public ActionResult ResetPassword()
        {
            forgotpassVM u = new forgotpassVM();
            return View(u);
        }

        [HttpPost]
        public ActionResult ResetPassword(forgotpassVM u) 
        {
            
             IUserQuery objIUserQuery;
            objIUserQuery = new UserQuery();

            if (u.password == u.confirmpass)
            {
                var r = objIUserQuery.userlist().Where(x => x.user_email == u.email).SingleOrDefault();

                r.password = u.password;
                
                objIUserQuery.updateuserpass(r);
            }
            else 
            {
                ViewBag.Message = "Password & Confirm password Not match";
            }
            return View("ResetPassword");
        }

        public ActionResult Login()
        {
            return View();
        }

        //public ActionResult usertable() 
        //{
        //    AllAccessVM access = new AllAccessVM();
        //    IUserQuery objIUserQuery;
        //    objIUserQuery = new UserQuery();

        //    List<UserVM> li = new List<UserVM>();

        //    UserVM uservm = new UserVM();
        //    var list = objIUserQuery.userlist();
        //    foreach (var i in list) 
        //    {
                
        //        uservm.usersid = i.usersid;
        //        uservm.email = i.user_email;
        //        uservm.user_name = i.user_name;
        //        uservm.phone = i.phone;
        //        uservm.password = i.password;
        //        uservm.created_date = i.created_date;
        //        uservm.orgid = objIUserQuery.orglist().Where(x=>x.org_id == i.org_id).SingleOrDefault().org_name;
        //       // uservm.roleid =Convert.ToString(i.roleid);

        //        uservm.roleid = objIUserQuery.useraccessslist().Where(x => x.id == i.roleid).SingleOrDefault() == null ? null: objIUserQuery.useraccessslist().Where(x => x.id == i.roleid).SingleOrDefault().role;
        //        li.Add(uservm);
        //    }
           

        //    //var userid=(TempData["userid"]);
        //    //var orgid = Session["orgid"];

        //    var userid = Session["userid"];


        //    var manage = objIUserQuery.userlist().Where(x => x.usersid == Convert.ToInt32(userid)).SingleOrDefault();

        //    //var screen = objIUserQuery.useraccessscreenlist().Where(x => x.useraccesssid == manage.roleid && x.modulename == "User").SingleOrDefault();

        //    //var screen = objIUserQuery.useraccessscreenlist().Where(x => x.useraccesssid == manage.roleid && x.usersid == Convert.ToInt32(manage.usersid)).SingleOrDefault();

        //    var screen = objIUserQuery.useraccessscreenlist().Where(x => x.useraccesssid == manage.roleid).ToList();

        //    foreach (var i in screen) 
        //    {
        //        access.modulename = i.modulename;
        //        access.add = i.adddata;
        //        access.edit = i.editdata;
        //        access.delete = i.deletedata;
        //    }

        //    access.uservmlist = li;


        //    //var screen = objIUserQuery.useraccessscreenlist().Where(x => x.useraccesssid == manage.roleid && x.modulename =="User").SingleOrDefault();
        //    //if (screen != null)
        //    //{
        //    //    access.modulename = screen.modulename;
        //    //    access.add = screen.adddata;
        //    //    access.edit = screen.editdata;
        //    //    access.delete = screen.deletedata;
        //    //}


        //    //else
        //    //{
        //    //    return View("ErrorPage");
        //    //}
        //    //return View(li);
        //    return View("usertable", access);
        //}


        public ActionResult usertable()
        {
            AllAccessVM access = new AllAccessVM();
            IUserQuery objIUserQuery;
            objIUserQuery = new UserQuery();

            List<UserVM> li = new List<UserVM>();

            UserVM uservm = new UserVM();
            var list = objIUserQuery.userlist();
            foreach (var i in list)
            {

                uservm.usersid = i.usersid;
                uservm.email = i.user_email;
                uservm.user_name = i.user_name;
                uservm.phone = i.phone;
                uservm.password = i.password;
                uservm.created_date = i.created_date;
                uservm.orgid = objIUserQuery.orglist().Where(x => x.org_id == i.org_id).SingleOrDefault().org_name;
                uservm.roleid = objIUserQuery.useraccessslist().Where(x => x.id == i.roleid).SingleOrDefault() == null ? null : objIUserQuery.useraccessslist().Where(x => x.id == i.roleid).SingleOrDefault().role;
                li.Add(uservm);
            }

            
            var userid = Session["userid"];
            var manage = objIUserQuery.userlist().Where(x => x.usersid == Convert.ToInt32(userid)).SingleOrDefault();

            access.uservmlist = li;

            if (manage.Flag == true)
            {
                access.add = true;
                access.edit = true;
                access.delete = true;
               //access.uservmlist= getfulluserlist(objIUserQuery);
               
                return View("usertable",access);
            }
            else
            {
                var screen = objIUserQuery.useraccessscreenlist().Where(x => x.useraccesssid == manage.roleid && x.modulename == "User").SingleOrDefault();

                access.uservmlist = li;
                if (screen != null)
                {
                    access.modulename = screen.modulename;
                    access.add = screen.adddata;
                    access.edit = screen.editdata;
                    access.delete = screen.deletedata;
                }

                else
                {
                    return View("ErrorPage");
                }
                return View("usertable", access);
            }

            
        }



        public List<UserVM> getfulluserlist(IUserQuery qry)
        {
            //AllAccessVM access = new AllAccessVM();

            //List<AllAccessVM> accessvm = new List<AllAccessVM>();

            List<UserVM> li = new List<UserVM>();
            var result = qry.userlist();
            foreach (var i in result)
            {
                UserVM u = new UserVM();
                u.usersid = i.usersid;
                u.user_name = i.user_name;
                u.email = i.user_email;
                u.password = i.password;
                u.phone = i.phone;
                u.created_date = i.created_date;
                u.orgid = qry.orglist().Where(x => x.org_id == i.org_id).SingleOrDefault().org_name;
                u.roleid = qry.useraccessslist().Where(x => x.id == i.roleid).SingleOrDefault().role;

                u.add = true;
                u.edit = true;
                u.delete = true;
                li.Add(u);
            }
            //access.uservmlist = li;


            return li;
        }

        //public ActionResult OrgTable() 
        //{
        //    IUserQuery objqry;
        //    objqry = new UserQuery();
        //    List<OrgVM> li = new List<OrgVM>();
        //    var list = objqry.orglist();
        //    foreach (var i in list) 
        //    {
        //        OrgVM orgvm = new OrgVM();
        //        orgvm.org_id = i.org_id;
        //        orgvm.org_name = i.org_name;
        //        orgvm.org_email = i.org_email;
        //        orgvm.org_address = i.org_address;
        //        orgvm.phone = i.phone;
        //        orgvm.created_date =Convert.ToDateTime(i.created_date);
        //        li.Add(orgvm);
        //    }
        //    return View("OrgTable", li);

        //}

        [HttpPost]
        public ActionResult Login(UserVM user,string Email,string password) 
        {
            IUserQuery objIUserQuery;
            objIUserQuery = new UserQuery();
            var check = objIUserQuery.checkuser(Email, password);
            //TempData["username"] = check.user_name;

            

            if (check != null)
            {

                //if (check.Flag == true)
                //{

                //}
                TempData["userid"] = check.usersid;

                Session["userid"] = check.usersid;
                Session["orgid"] = check.org_id;
                return View("Index");
                //return Json(new { success = true }, JsonRequestBehavior.AllowGet);
            }
            else 
            {
                ViewBag.Message = "Email & password Not match";
                return View();
                //return Json(new { success = false }, JsonRequestBehavior.AllowGet);
            }
        }

    
        public ActionResult user()
        {
            UserVM objuservm = new UserVM();
            IUserQuery objIUserQuery;
            objIUserQuery = new UserQuery();
            objuservm.Organization = new SelectList(objIUserQuery.orglist(), "org_id", "org_name");
            objuservm.roles = new SelectList(objIUserQuery.useraccessslist(), "id", "role");
            return View("user", objuservm);
            
        }

        [HttpPost]
        public ActionResult SaveUserData(UserVM objuservm)
        {
            IUserQuery objQuery;
            objQuery = new UserQuery();

            UserVM uservm = new UserVM();
            uservm.Organization = new SelectList(objQuery.orglist(), "org_id", "org_name");

            uservm.roles = new SelectList(objQuery.useraccessslist(), "id", "role");

            if (ModelState.IsValid)
            {
                var organization = objQuery.orglist().Where(x => x.org_id == Convert.ToInt32(objuservm.orgid)).SingleOrDefault();

                var check = objQuery.checkuserByEmail(objuservm.email);
              
                if (check == null)
                {
                    try
                    {
                        users u = new users();
                        u.user_name = objuservm.user_name;
                        u.user_email = objuservm.email;
                        u.phone = objuservm.phone;
                        u.password = objuservm.password;
                        u.created_date = DateTime.Now;
                        //u.org_id = Convert.ToInt32(objuservm.orgid);
                        u.org_id = organization.org_id;
                        u.created_By = Convert.ToString(Session["userid"]);
                        u.roleid =Convert.ToInt32(objuservm.roleid);
                        objQuery.saveuser(u);
                        //return View("user");
                        return RedirectToAction("Index");
                    }
                    catch (Exception ex)
                    {
                        return View(uservm);
                    }
                }
                else 
                {
                    ViewBag.Message = "Email Already Exist";
                    return View("user",uservm);
                }
            
            }
            else
            {
                return View(uservm);
            }
        }

        //public ActionResult Organization()
        //{

        //    return View("Organization");

        //}


        //[HttpPost]
        //public ActionResult Organization(OrgVM objorgvm)
        //{
        //    IUserQuery objquery;
        //    objquery = new UserQuery();

        //    var check = objquery.checkorgByEmail(objorgvm.org_email);
        //    if (check == null)
        //    {
        //        try
        //        {
        //            org o = new org();
        //            o.org_name = objorgvm.org_name;
        //            o.org_email = objorgvm.org_email;
        //            o.org_address = objorgvm.org_address;
        //            o.phone = objorgvm.phone;
        //            o.created_date = DateTime.Now;
        //            o.created_By = Convert.ToString(TempData["userid"]);
        //            objquery.saveorg(o);
        //            //return View("Organization");
        //            return RedirectToAction("Index");
        //        }
        //        catch (Exception ex)
        //        {
        //            return View(objorgvm);
        //        }
        //    }
        //    else
        //    {
        //        ViewBag.Message = "Email Already Exist";
        //        return View(objorgvm);
        //    }

        //}


        [HttpGet]
        public ActionResult EditUser(int usersid) 
        {
             IUserQuery objIUserQuery;
            objIUserQuery = new UserQuery();

            UserVM u = new UserVM();
            u.Organization = new SelectList(objIUserQuery.orglist(), "org_id", "org_name");

            u.roles = new SelectList(objIUserQuery.useraccessslist(), "id", "role");

            var result = objIUserQuery.checkuserByid(usersid);

           

            u.usersid = result.usersid;
            u.user_name = result.user_name;
            u.email = result.user_email;
            u.password = result.password;
            u.phone = result.phone;
            u.orgid = Convert.ToString(result.org_id);
            u.roleid = Convert.ToString(result.roleid);
            return View(u);
        }


        [HttpPost]
        public ActionResult EditUser(UserVM uservm)
        {
            IUserQuery objIUserQuery;
            objIUserQuery = new UserQuery();

            var u = objIUserQuery.checkuserByid(uservm.usersid);
            u.user_name = uservm.user_name;
            u.user_email = uservm.email;
            u.password = uservm.password;
            u.phone = uservm.phone;
            u.modified_date = DateTime.Now;
            u.org_id = Convert.ToInt32(uservm.orgid);
            u.roleid =  Convert.ToInt32(uservm.roleid);
            objIUserQuery.updateUserdata(u);
            //return null;
            //return RedirectToAction("usertable", uservm);
            //return View("EditUser", uservm);
            bool msg = false;
            return Json(msg);
        }

        //public ActionResult EditUser(UserVM uservm) 
        //{
        //    IUserQuery objIUserQuery;
        //    objIUserQuery = new UserQuery();

        //    var u = objIUserQuery.checkuserByid(uservm.usersid);
        //    u.user_name = uservm.user_name;
        //    u.user_email = uservm.email;
        //    u.password = uservm.password;
        //    u.phone = uservm.phone;
        //    u.modified_date = DateTime.Now;
        //    u.org_id = Convert.ToInt32(uservm.orgid);
        //    objIUserQuery.updateUserdata(u);
        //    //return View("EditUser", uservm);
        //    bool msg = false;
        //    return Json(msg);
        //}


        //public ActionResult EditOrg(int org_id) 
        //{
        //    IUserQuery objIUserQuery;
        //    objIUserQuery = new UserQuery();
        //    var u = objIUserQuery.checkOrgByid(org_id);

        //    OrgVM objorg = new OrgVM();
        //    objorg.org_name = u.org_name;
        //    objorg.org_email = u.org_email;
        //    objorg.phone = u.phone;
        //    objorg.org_address = u.org_address;
        //    return View(objorg);
        //}

        //[HttpPost]
        //public ActionResult EditOrg(OrgVM orgvm) 
        //{

        //    IUserQuery objIUserQuery;
        //    objIUserQuery = new UserQuery();
        //    var u = objIUserQuery.checkOrgByid(orgvm.org_id);

        //    u.org_name = orgvm.org_name;
        //    u.org_email = orgvm.org_email;
        //    u.org_address = orgvm.org_address;
        //    u.phone = orgvm.phone;
        //    u.modified_date = DateTime.Now;
        //    objIUserQuery.updateOrgData(u);
        //    return View();
        //}

        public ActionResult DeleteUser(int usersid) 
        {
            IUserQuery objIUserQuery;
            objIUserQuery = new UserQuery();
            try
            {
                var t = objIUserQuery.deleteuserdata(usersid);
                objIUserQuery.deleteuser(t);
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            catch(Exception ex)
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }


        //public ActionResult DeleteOrg(int org_id)
        //{
        //    IUserQuery objIUserQuery;
        //    objIUserQuery = new UserQuery();
        //    var t = objIUserQuery.deleteorgdata(org_id);
        //    objIUserQuery.deleteorg(t);
        //    return RedirectToAction("Index");
        //}

       


        public JsonResult getuserdataTable(DataTablesParam param)
        {
            IUserQuery objIUserQuery;
            objIUserQuery = new UserQuery();

            UserVM uservm = new UserVM();

            int userid =Convert.ToInt32(Session["userid"]);

            var lstuser = uservm.getuserlist(objIUserQuery, userid);

           
            //AllAccessVM accessvm = new AllAccessVM();
            //var screenuser = accessvm.getuserscreenlist(objIUserQuery);

           // var screenuser = uservm.getuserscreenlist(objIUserQuery);
            //var screenuser = uservm.getuserscreenlist(objIUserQuery);
            
            //var lstorg= objIUserQuery.userlist();
            IEnumerable<UserVM> IEnumerableUserVM;
            IEnumerable<string[]> result;
            ApplyDatatableFunctionsForUser(param, lstuser, out IEnumerableUserVM, out result);
            return Json(new
            {
                sEcho = param.sEcho,
                iTotalRecords = lstuser.Count(),
                iTotalDisplayRecords = IEnumerableUserVM.Count(),
                aaData = result
            }, JsonRequestBehavior.AllowGet);
        }





        public void ApplyDatatableFunctionsForUser(DataTablesParam param, List<UserVM> allCompanies, out IEnumerable<UserVM> filteredCompanies, out IEnumerable<string[]> result)
        {
            try
            {
                #region Filtering
                if (!string.IsNullOrEmpty(param.sSearch))
                {
                    filteredCompanies = allCompanies
                             .Where(c => c.user_name.Contains(param.sSearch)
                                 || c.email.Contains(param.sSearch));
                    
                }
                else
                {
                    filteredCompanies = allCompanies;
                   

                }
                #endregion
                #region Sorting
                var sortColumnIndex = Convert.ToInt32(Request["iSortCol_0"]);
                //Func<RentVM, string> orderingFunction = (c => sortColumnIndex == 2 ? c.Tenant_Name.ToString() : Convert.ToString(c.Tenant_Name));
                Func<UserVM, string> orderingFunction = (c => sortColumnIndex == 1 ? c.usersid.ToString() : Convert.ToString(c.usersid));
                var sortDirection = Request["sSortDir_0"]; // asc or desc
                if (sortDirection == "asc")
                    filteredCompanies = filteredCompanies.OrderBy(orderingFunction);
                else
                    filteredCompanies = filteredCompanies.OrderByDescending(orderingFunction);
                filteredCompanies.OrderByDescending(orderingFunction);
                var displayedCompanies = filteredCompanies;

                //var screen = allCompanies1;

                //result = from c in displayedCompanies from s in screen
                result = from c in displayedCompanies 
                         select new[] { Convert.ToString(c.usersid), Convert.ToString(c.user_name), Convert.ToString(c.email), Convert.ToString(c.phone), Convert.ToString(c.password), Convert.ToString(c.orgid), Convert.ToString(c.roleid), Convert.ToString(c.created_date),null,null ,Convert.ToString(c.add), Convert.ToString(c.edit), Convert.ToString(c.delete)};


                //result = from a in displayedCompanies
                //         join
                //         s in screen on a.usersid equals s.usersid
                //         select new
                //         {
                //             a.usersid,
                //             a.user_name,
                //             a.email,
                //             a.phone,
                //             a.password,
                //             a.orgid,
                //             a.roleid,
                //             a.created_date,
                //             s.add,
                //             s.edit,
                //             s.delete
                //         };


                #endregion

                #region pagination
                result = result
                            .Skip(param.iDisplayStart)
                            .Take(param.iDisplayLength);
                #endregion
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        public ActionResult forgotpass() 
      
        {
            return View();
            //return Json(fvm, JsonRequestBehavior.AllowGet);
           // return Json(new { dtrData = fvm });
        }


        [HttpPost]
        public ActionResult forgotpassSAVE(forgotpassVM fvm)
        {

            IUserQuery objIUserQuery;
            objIUserQuery = new UserQuery();
            var result = objIUserQuery.userlist().Where(x => x.user_email == fvm.email).SingleOrDefault();
            if (result == null)
            {
                ViewBag.Message = "Invalid Email";
                return View("forgotpass");
            }
            else
            {
                //if (result != null)
                //{
                //    fvm.password = result.password;
                //}
                //else
                //{
                //    ViewBag.Message = "Invalid Email";
                //}
                return View("Resetpass", fvm);
            }
        }


        //[HttpPost]
        //public ActionResult forgotpassSAVE(forgotpassVM fvm)
        //{

        //    IUserQuery objIUserQuery;
        //    objIUserQuery = new UserQuery();
        //    var result = objIUserQuery.userlist().Where(x => x.user_email == fvm.email).SingleOrDefault();
        //    if (result == null)
        //    {
        //        ViewBag.Message = "Invalid Email";
        //    }
        //    //if (result != null)
        //    //{
        //    //    fvm.password = result.password;
        //    //}
        //    //else
        //    //{
        //    //    ViewBag.Message = "Invalid Email";
        //    //}
        //    return View("Resetpass", fvm);
        //}


        [HttpGet]
        public ActionResult Resetpass()
        {
            forgotpassVM fvm = new forgotpassVM();
            return View(fvm);
        }

        [HttpPost]
        public ActionResult Resetpass(forgotpassVM fvm) 
        { 
            IUserQuery objIUserQuery;
            objIUserQuery = new UserQuery();
           
            if (fvm.newpassword == fvm.confirmpass)
            {
                var result = objIUserQuery.userlist().Where(x => x.user_email == fvm.email).SingleOrDefault();
                result.password = fvm.newpassword;
                objIUserQuery.updateuserpass(result);
               
            }
            else 
            {
                ViewBag.Message = "Invalid password";
               return View("Resetpass", fvm);
            }
            return RedirectToAction("Resetpass");
           
        }


  
        public ActionResult Reports(string ReportType)
        {
            IUserQuery objIUserQuery;
            objIUserQuery = new UserQuery();
            var db = objIUserQuery.userlist();

            //LocalReport localreport = new LocalReport();
            ReportViewer rv = new ReportViewer();

            //localreport.ReportPath = Server.MapPath("/Reports/Report2.rdlc");
           // rv.LocalReport.ReportPath = Server.MapPath("/Reports/Report1.rdlc");
            rv.LocalReport.ReportPath = Server.MapPath("/Reports/Report2.rdlc");

            //DataSet  
            //testDataSet frndDataSet = new testDataSet();


            // Create Report DataSource  
            ReportDataSource reportdatasource = new ReportDataSource();
            reportdatasource.Name = "DataSet1";

            //List<users> li = new List<users>();

            List<reportvm> li = new List<reportvm>();
         
            foreach (var i in db)
            {
                reportvm u = new reportvm();
                
                u.userid = i.usersid;
                u.user_name = i.user_name;
                u.user_email = i.user_email;
                u.phone = i.phone;
                u.password = i.password;
                u.org_id = objIUserQuery.orglist().Where(x => x.org_id == i.org_id).SingleOrDefault().org_name;
                u.roleid = objIUserQuery.useraccessslist().Where(x => x.id == i.roleid).SingleOrDefault().role;
                u.created_date = i.created_date;
                li.Add(u);
            }
            reportdatasource.Value = li;
            rv.LocalReport.DataSources.Add(reportdatasource);
            //rv.LocalReport.Refresh();
            //rv.DataBind();
            // Variables  
            Warning[] warnings = null;
            string reportType = ReportType;
            string mimeTime = null;
            string encoding = null;
            string extension = null;
            if (reportType == "Excel")
            {
                extension = "xlsx";
            }
            if (reportType == "Word")
            {
                extension = "docx";
            }
            if (reportType == "PDF")
            {
                extension = "pdf";
            }
            // Setup the report viewer object and get the array of bytes  

            string[] streams = null;
            byte[] renderdByte;

            renderdByte = rv.LocalReport.Render(reportType, "", out mimeTime, out encoding, out extension, out streams, out warnings);
            Response.AddHeader("content-disposition", "Attachment;fileName=UserReport." + extension);
            return File(renderdByte, extension);
        }
    }
}
