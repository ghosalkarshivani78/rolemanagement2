﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using orgUsermanage.Query;
using orgUsermanage.Models;
using System.IO;
using System.Data;
using orgUsermanage.Controllers.ViewModels.DataTable;
using orgUsermanage.Controllers.ViewModels;

namespace orgUsermanage.Controllers
{
    public class OrgController : Controller
    {
        //
        // GET: /Org/

        public ActionResult Index()
        {
            OrgVM org = new OrgVM();
            return View(org);
        }

        public ActionResult OrgTable()
        {
            IUserQuery objqry;
            objqry = new UserQuery();

            var userid = Session["userid"];
            var access = objqry.useraccessslist();
            var screens = objqry.useraccessscreenlist();

            AllAccessVM accessvm = new AllAccessVM();

            List<AllAccessVM> accessli = new List<AllAccessVM>();

            List<OrgVM> li = new List<OrgVM>();
            OrgVM orgvm = new OrgVM();

            //var list = objqry.orglist();

            var user=objqry.userlist().Where(x=>x.usersid ==Convert.ToInt32(userid)).SingleOrDefault();
            var list = objqry.orglist().Where(x => x.org_id == user.org_id).ToList();
            foreach (var i in list)
            {
                
                orgvm.org_id = i.org_id;
                orgvm.org_name = i.org_name;
                orgvm.org_email = i.org_email;
                orgvm.org_address = i.org_address;
                orgvm.phone = i.phone;
                orgvm.created_date = Convert.ToDateTime(i.created_date);
                li.Add(orgvm);
            }

           // var userid = Session["userid"];

            var manage = objqry.userlist().Where(x => x.usersid == Convert.ToInt32(userid)).SingleOrDefault();

            accessvm.orgvmlist = li;

            if (manage.Flag == true)
            {
                accessvm.add = true;
                accessvm.edit = true;
                accessvm.delete = true;
                return View("OrgTable", accessvm);
            }
            else
            {

                var screen = objqry.useraccessscreenlist().Where(x => x.useraccesssid == manage.roleid && x.modulename == "Organization").SingleOrDefault();

                // var screen = objqry.useraccessscreenlist().Where(x => x.useraccesssid == manage.roleid && x.usersid == manage.usersid).SingleOrDefault();

                accessvm.orgvmlist = li;

                if (screen != null)
                {
                    accessvm.modulename = screen.modulename;
                    accessvm.add = screen.adddata;
                    accessvm.edit = screen.editdata;
                    accessvm.delete = screen.deletedata;
                }
                else
                {
                    return View("ErrorPage");
                }
            }
          //  return View(li);
            return View(accessvm);

        }

        public ActionResult Organization()
        {

            return View("Organization");

        }


        [HttpPost]
        public ActionResult Organization(OrgVM objorgvm)
        {
            IUserQuery objquery;
            objquery = new UserQuery();

            var check = objquery.checkorgByEmail(objorgvm.org_email);
            if (check == null)
            {
                try
                {
                    org o = new org();
                    o.org_name = objorgvm.org_name;
                    o.org_email = objorgvm.org_email;
                    o.org_address = objorgvm.org_address;
                    o.phone = objorgvm.phone;
                    o.created_date = DateTime.Now;
                    o.created_By = Convert.ToString(TempData["userid"]);
                    objquery.saveorg(o);
                    //return View("Organization");
                    //return RedirectToAction("OrgTable");


                    bool msg = false;
                    return Json(msg);
                }
                catch (Exception ex)
                {
                    bool msg = true;
                    return Json(msg);
                }
            }
            else
            {
                ViewBag.Message = "Email Already Exist";
                return View(objorgvm);
            }

        }

        public ActionResult EditOrg(int org_id)
        {
            IUserQuery objIUserQuery;
            objIUserQuery = new UserQuery();
            var u = objIUserQuery.checkOrgByid(org_id);

            OrgVM objorg = new OrgVM();
            objorg.org_name = u.org_name;
            objorg.org_email = u.org_email;
            objorg.phone = u.phone;
            objorg.org_address = u.org_address;
            return View(objorg);
        }

        [HttpPost]
        public ActionResult EditOrg(OrgVM orgvm)
        {

            IUserQuery objIUserQuery;
            objIUserQuery = new UserQuery();
            var u = objIUserQuery.checkOrgByid(orgvm.org_id);

            u.org_name = orgvm.org_name;
            u.org_email = orgvm.org_email;
            u.org_address = orgvm.org_address;
            u.phone = orgvm.phone;
            u.modified_date = DateTime.Now;
            objIUserQuery.updateOrgData(u);
            //return View();
            //return RedirectToAction("OrgTable", orgvm);
            bool msg = false;
            return Json(msg);
        }

        public ActionResult DeleteOrg(int org_id)
        {
            IUserQuery objIUserQuery;
            objIUserQuery = new UserQuery();
            try
            {
                var t = objIUserQuery.deleteorgdata(org_id);
                objIUserQuery.deleteorg(t);
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            catch(Exception ex)
            {
                 bool msg = true;
                 return Json(false, JsonRequestBehavior.AllowGet);
            }
            
        }

        public JsonResult getOrgdataTable(DataTablesParam param)
        {
            IUserQuery objIUserQuery;
            objIUserQuery = new UserQuery();

            OrgVM orgvm = new OrgVM();
            int userid = Convert.ToInt32(Session["userid"]);

            var lstorg = orgvm.getorglist(objIUserQuery, userid);
            //var lstorg= objIUserQuery.userlist();
            IEnumerable<OrgVM> IEnumerableOrgVM;
            IEnumerable<string[]> result;
            ApplyDatatableFunctionsForOrg(param, lstorg, out IEnumerableOrgVM, out result);
            return Json(new
            {
                sEcho = param.sEcho,
                iTotalRecords = lstorg.Count(),
                iTotalDisplayRecords = IEnumerableOrgVM.Count(),
                aaData = result
            }, JsonRequestBehavior.AllowGet);
        }

        public void ApplyDatatableFunctionsForOrg(DataTablesParam param, List<OrgVM> allCompanies, out IEnumerable<OrgVM> filteredCompanies, out IEnumerable<string[]> result)
        {
            try
            {
                #region Filtering
                if (!string.IsNullOrEmpty(param.sSearch))
                {
                    filteredCompanies = allCompanies
                             .Where(c => c.org_name.Contains(param.sSearch)
                                 || c.org_email.Contains(param.sSearch));
                }
                else
                {
                    filteredCompanies = allCompanies;
                }
                #endregion
                #region Sorting
                var sortColumnIndex = Convert.ToInt32(Request["iSortCol_0"]);
                //Func<RentVM, string> orderingFunction = (c => sortColumnIndex == 2 ? c.Tenant_Name.ToString() : Convert.ToString(c.Tenant_Name));
                Func<OrgVM, string> orderingFunction = (c => sortColumnIndex == 1 ? c.org_id.ToString() : Convert.ToString(c.org_id));
                var sortDirection = Request["sSortDir_0"]; // asc or desc
                if (sortDirection == "asc")
                    filteredCompanies = filteredCompanies.OrderBy(orderingFunction);
                else
                    filteredCompanies = filteredCompanies.OrderByDescending(orderingFunction);
                filteredCompanies.OrderByDescending(orderingFunction);
                var displayedCompanies = filteredCompanies;

                result = from c in displayedCompanies
                         select new[] { Convert.ToString(c.org_id), Convert.ToString(c.org_name), Convert.ToString(c.org_address), Convert.ToString(c.org_email), Convert.ToString(c.phone), Convert.ToString(c.created_date), null, null, Convert.ToString(c.add), Convert.ToString(c.edit), Convert.ToString(c.delete) };



                #endregion

                #region pagination
                result = result
                            .Skip(param.iDisplayStart)
                            .Take(param.iDisplayLength);
                #endregion
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ActionResult LoadType()
        {
            return null;
        }

 
    }
}
