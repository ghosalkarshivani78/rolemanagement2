﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using orgUsermanage.Query;
using orgUsermanage.Controllers.ViewModels;
using orgUsermanage.Models;
using orgUsermanage.Controllers.ViewModels.DataTable;
using Microsoft.Reporting.WebForms;

namespace orgUsermanage.Controllers
{
    public class manageController : Controller
    {
        //
        // GET: /manage/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult manageTable()
        {
            var id = Session["userid"];
            AllAccessVM access = new AllAccessVM();
            List<Managelist> li = new List<Managelist>();

            IUserQuery objIUserQuery;
            objIUserQuery = new UserQuery();

            var usertable = objIUserQuery.userlist();
            var useaccess = objIUserQuery.useraccessslist();
            var useraccessscreen = objIUserQuery.useraccessscreenlist();

            var manage = objIUserQuery.userlist().Where(x => x.usersid == Convert.ToInt32(id)).SingleOrDefault();

            if (manage.Flag == true)
            {
              
                var result = (from a in useraccessscreen
                              join
                              s in useaccess on a.useraccesssid equals s.id
                              select new
                              {
                                  a.id,
                                  a.modulename,
                                  a.adddata,
                                  a.editdata,
                                  a.deletedata,
                                  a.useraccesssid,
                                  a.usersid,
                                  s.role,
                                  s.description
                              }).ToList();



                foreach (var i in result)
                {
                    Managelist m = new Managelist();
                    m.id = i.id;
                    m.modulename = i.modulename;
                    m.role = i.role;
                    m.description = i.description;
                    m.add = i.adddata;
                    m.edit = i.editdata;
                    m.delete = i.deletedata;
                    var t = Convert.ToString(i.useraccesssid);
                    //m.useraccessid = i.useraccesssid;
                    t = Convert.ToString(objIUserQuery.useraccessslist().Where(x => x.id == i.useraccesssid).SingleOrDefault().role);
                   
                    m.useraccessid = Convert.ToString(t);
                    m.usersid = i.usersid;
                    li.Add(m);

                }
                access.mangevmlist = li;
                access.add = true;
                access.edit = true;
                access.delete = true;
                return View("manageTable", access);
            }
            else
            {

                var result = (from a in useraccessscreen
                              join
                              s in useaccess on a.useraccesssid equals s.id
                              //s in useaccess on a.useraccesssid equals s.id
                              //join u in usertable on a.usersid equals u.usersid
                              select new
                              {
                                  a.id,
                                  a.modulename,
                                  a.adddata,
                                  a.editdata,
                                  a.deletedata,
                                  a.useraccesssid,
                                  a.usersid,
                                  s.role,
                                  s.description
                              }).ToList();

                var r = result.Where(x => x.useraccesssid == manage.roleid && x.modulename == "UserManage");
                
                //var r = result.Where(x=>x.modulename == "UserManage");

                foreach (var i in r)
                {
                    Managelist m = new Managelist();
                    m.id = i.id;
                    m.modulename = i.modulename;
                    m.role = i.role;
                    m.description = i.description;
                    m.add = i.adddata;
                    m.edit = i.editdata;
                    m.delete = i.deletedata;
                   // m.useraccessid = Convert.ToString(i.useraccesssid);
                    m.useraccessid = objIUserQuery.useraccessslist().Where(x => x.id == i.useraccesssid).SingleOrDefault().role;
                    m.usersid = i.usersid;
                    li.Add(m);

                }

                    var checkscreen = objIUserQuery.useraccessscreenlist().Where(x => x.useraccesssid == manage.roleid && x.modulename == "UserManage").SingleOrDefault();

           
                    access.mangevmlist = li;

                    if (checkscreen != null)
                    {
                        access.modulename = checkscreen.modulename;
                        access.add = checkscreen.adddata;
                        access.edit = checkscreen.editdata;
                        access.delete = checkscreen.deletedata;
                    }

                    else
                    {
                        return View("ErrorPage");
                    }
                }
                return View(access);
            }
        

        //public ActionResult manageTable()
        //{
        //    var id = Session["userid"];
        //    AllAccessVM access = new AllAccessVM();
        //    List<Managelist> li = new List<Managelist>();

        //     IUserQuery objIUserQuery;
        //    objIUserQuery = new UserQuery();

        //    var usertable = objIUserQuery.userlist();
        //    var useaccess = objIUserQuery.useraccessslist();
        //    var useraccessscreen = objIUserQuery.useraccessscreenlist();

        //    var result = (from a in useraccessscreen  
        //                  join
        //                  s in useaccess on a.useraccesssid equals s.id
              
        //                  //s in useaccess on a.useraccesssid equals s.id
        //                  //join u in usertable on a.usersid equals u.usersid
        //                 select new
        //                 {
        //                    a.id,
        //                    a.modulename,
        //                    a.adddata,
        //                    a.editdata,
        //                    a.deletedata,
        //                    a.useraccesssid,
        //                    a.usersid,
        //                    s.role,
        //                    s.description
        //                 }).ToList();

        //    foreach (var i in result) 
        //    {
        //        Managelist m = new Managelist();
        //        m.id = i.id;
        //        m.modulename = i.modulename;
        //        m.role = i.role;
        //        m.description = i.description;
        //        m.add = i.adddata;
        //        m.edit = i.editdata;
        //        m.delete = i.deletedata;
        //        m.useraccessid = i.useraccesssid;
        //        m.usersid=i.usersid;
        //        li.Add(m);

        //    }


        //    //var id = objIUserQuery.userlist().LastOrDefault().usersid;
           

        //    var manage = objIUserQuery.userlist().Where(x => x.usersid == Convert.ToInt32(id)).SingleOrDefault();
        //    access.mangevmlist = li;
        //    if (manage.Flag == true)
        //    {
        //        access.add = true;
        //        access.edit = true;
        //        access.delete = true;
        //        return View("manageTable", access);
        //    }
        //    else
        //    {

        //        //  var checkscreen = objIUserQuery.useraccessscreenlist().Where(x => x.useraccesssid == manage.roleid).ToList().SingleOrDefault();

        //        var checkscreen = objIUserQuery.useraccessscreenlist().Where(x => x.useraccesssid == manage.roleid && x.modulename == "UserManage").SingleOrDefault();


        //        access.mangevmlist = li;

        //        if (checkscreen != null)
        //        {
        //            access.modulename = checkscreen.modulename;
        //            access.add = checkscreen.adddata;
        //            access.edit = checkscreen.editdata;
        //            access.delete = checkscreen.deletedata;
        //        }

        //        else
        //        {
        //            return View("ErrorPage");
        //        }
        //    }
        //    return View(access);
        //}

      
        
       

        public ActionResult managecreate()
        {
            return View();
        } 

        //
        // POST: /manage/Create

        [HttpPost]
        public ActionResult managecreate(manage m)
        {
            IUserQuery objIUserQuery;
            objIUserQuery = new UserQuery();

            var user_id = Session["userid"];

            try
            {
                useraccesss ua = new useraccesss();
                ua.role = m.role;
                ua.description = m.description;
                objIUserQuery.saveuseraccess(ua);

                if (m.User != null)
                {
                    useraccessscreen s = new useraccessscreen();
                    s.modulename = m.User;
                    s.adddata = m.useraccessadd;
                    s.editdata = m.useraccessedit;
                    s.deletedata = m.useraccessdelete;
                    s.useraccesssid = ua.id;
                    s.usersid = Convert.ToInt32(user_id);
                    objIUserQuery.savescreen(s);
                }

                if (m.organization != null)
                {
                    useraccessscreen s = new useraccessscreen();
                    s.modulename = m.organization;
                    s.adddata = m.orgaccessadd;
                    s.editdata = m.orgaccessedit;
                    s.deletedata = m.orgaccessdelete;
                    s.useraccesssid = ua.id;
                    s.usersid = Convert.ToInt32(user_id);
                    objIUserQuery.savescreen(s);
                }

                if (m.UserManage != null)
                {
                    useraccessscreen s = new useraccessscreen();
                    s.modulename = m.UserManage;
                    s.adddata = m.manageaccessadd;
                    s.editdata = m.manageaccessedit;
                    s.deletedata = m.manageaccessdelete;
                    s.useraccesssid = ua.id;
                    s.usersid = Convert.ToInt32(user_id);
                    objIUserQuery.savescreen(s);
                }

                //return View();

                //return RedirectToAction("manageTable",m);
                bool msg = false;
                return Json(msg);
            }
            catch 
            {
                bool msg = true;
                return Json(msg);
            }
            
        }
        

        [HttpGet]
        public ActionResult Editmanage(int id) 
        {
            IUserQuery objIUserQuery;
            objIUserQuery = new UserQuery();

            manage u = new manage();


            var screen = objIUserQuery.useraccessscreenlist().Where(x => x.id == id).SingleOrDefault();

            var access = objIUserQuery.useraccessslist().Where(x => x.id == screen.useraccesssid).SingleOrDefault();


            u.role = access.role;
            u.description = access.description;

            if (screen.modulename == "User")
            {
                u.User = screen.modulename;
                u.useraccessadd = screen.adddata;
                u.useraccessedit = screen.editdata;
                u.useraccessdelete = screen.deletedata;
                u.modulename = screen.modulename;
            }
            if (screen.modulename == "Organization")
            {
                u.organization = screen.modulename;
                u.orgaccessadd = screen.adddata;
                u.orgaccessedit = screen.editdata;
                u.orgaccessdelete = screen.deletedata;
                u.modulename = screen.modulename;
            }
            if (screen.modulename == "UserManage")
            {
                u.UserManage = screen.modulename;
                u.manageaccessadd = screen.adddata;
                u.manageaccessedit = screen.editdata;
                u.manageaccessdelete = screen.deletedata;
                u.modulename = screen.modulename;
            }

            return View(u);
        }


        [HttpPost]
        public ActionResult EditManageData(manage m) 
        {
            
            IUserQuery objIUserQuery;
            objIUserQuery = new UserQuery();
            try
            {

                var manage = objIUserQuery.useraccessscreenlist().Where(x => x.id == m.id).SingleOrDefault();

                var access = objIUserQuery.useraccessslist().Where(x => x.id == manage.useraccesssid).SingleOrDefault();

                access.role = m.role;
                access.description = m.description;
                //objIUserQuery.saveuseraccess(access);
                objIUserQuery.updateuseraccess(access);

                if (manage.modulename == "User")
                //if(m.User !=null)
                {
                    manage.modulename = m.User;
                    manage.adddata = m.useraccessadd;
                    manage.editdata = m.useraccessedit;
                    manage.deletedata = m.useraccessdelete;
                    objIUserQuery.updatemanagedata(manage);
                }


                if (manage.modulename == "Organization")
                //if(m.organization !=null)
                {
                    manage.modulename = m.organization;
                    manage.adddata = m.orgaccessadd;
                    manage.editdata = m.orgaccessedit;
                    manage.deletedata = m.orgaccessdelete;
                    objIUserQuery.updatemanagedata(manage);
                }

                if (manage.modulename == "UserManage")
                //if(m.UserManage != null)
                {
                    manage.modulename = m.UserManage;
                    manage.adddata = m.manageaccessadd;
                    manage.editdata = m.manageaccessedit;
                    manage.deletedata = m.manageaccessdelete;
                    objIUserQuery.updatemanagedata(manage);
                }



                //return View();
                bool msg = false;
                return Json(msg);
            }
            catch
            {
                bool msg = true;
                return Json(msg);
            }
        }


        public ActionResult Deletemanage(int id) 
        {
            IUserQuery objIUserQuery;
            objIUserQuery = new UserQuery();


            var result = objIUserQuery.useraccessscreenlist().Where(x => x.id == id).SingleOrDefault();
            

            var r = objIUserQuery.useraccessscreenlist().Where(x => x.useraccesssid == result.useraccesssid).Count();

            if (r == 1)
            {
                objIUserQuery.deleteaccess(result.useraccesssid);
            }


            objIUserQuery.deletescreen(result);
            //return View();
            bool msg = false;
            return Json(msg);
        }


        //public ActionResult addmanage(int id, bool adddata) 
        //{
        //    IUserQuery objIUserQuery;
        //    objIUserQuery = new UserQuery();

        //    var result = objIUserQuery.useraccessscreenlist().Where(x => x.id == id).SingleOrDefault();
        //    result.adddata = adddata;

        //    objIUserQuery.savescreen(result);
        //    //return View();
        //    return Json(JsonRequestBehavior.AllowGet);
        //}

        //public ActionResult EditManage(int id, bool editdata) 
        //{
        //    IUserQuery qry;
        //    qry = new UserQuery();
        //    var result = qry.useraccessscreenlist().Where(x => x.id == id).SingleOrDefault();

        //    result.editdata = editdata;
        //    qry.savescreen(result);
        //    return Json(JsonRequestBehavior.AllowGet);
        //}

        //public ActionResult DeleteManage(int id, bool deletedata)
        //{
        //    IUserQuery qry;
        //    qry = new UserQuery();
        //    var result = qry.useraccessscreenlist().Where(x => x.id == id).SingleOrDefault();

        //    result.deletedata = deletedata;
        //    qry.savescreen(result);
        //    return Json(JsonRequestBehavior.AllowGet);
        //}







        public JsonResult getmanagedataTable(DataTablesParam param)
        {
            IUserQuery objIUserQuery;
            objIUserQuery = new UserQuery();

            manage accessvm = new manage();

            int userid =Convert.ToInt32(Session["userid"]);


            var lstuser = accessvm.getmanagelist(objIUserQuery, userid);

            IEnumerable<manage> IEnumerableUserVM;
            IEnumerable<string[]> result;
            ApplyDatatableFunctionsForUser(param, lstuser, out IEnumerableUserVM, out result);
            return Json(new
            {
                sEcho = param.sEcho,
                iTotalRecords = lstuser.Count(),
                iTotalDisplayRecords = IEnumerableUserVM.Count(),
                aaData = result
            }, JsonRequestBehavior.AllowGet);
        }





        public void ApplyDatatableFunctionsForUser(DataTablesParam param, List<manage> allCompanies, out IEnumerable<manage> filteredCompanies, out IEnumerable<string[]> result)
        {
            try
            {
                #region Filtering
                if (!string.IsNullOrEmpty(param.sSearch))
                {
                    filteredCompanies = allCompanies
                             .Where(c => c.role.Contains(param.sSearch)
                                 || c.role.Contains(param.sSearch));
                    
                }
                else
                {
                    filteredCompanies = allCompanies;
                   

                }
                #endregion
                #region Sorting
                var displayedCompanies = filteredCompanies;

                //var screen = allCompanies1;

                //result = from c in displayedCompanies from s in screen
                result = from c in displayedCompanies
                         select new[] { Convert.ToString(c.id), Convert.ToString(c.role), Convert.ToString(c.description), Convert.ToString(c.useraccesssid), Convert.ToString(c.usersid), Convert.ToString(c.modulename), Convert.ToString(c.add), Convert.ToString(c.edit), Convert.ToString(c.delete) };


                #endregion

                #region pagination
                result = result
                            .Skip(param.iDisplayStart)
                            .Take(param.iDisplayLength);
                #endregion
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public ActionResult Reports(string ReportType)
        {
            IUserQuery objIUserQuery;
            objIUserQuery = new UserQuery();
            var db = objIUserQuery.useraccessscreenlist();

            //LocalReport localreport = new LocalReport();
            ReportViewer rv = new ReportViewer();

            //localreport.ReportPath = Server.MapPath("/Reports/Report2.rdlc");

            rv.LocalReport.ReportPath = Server.MapPath("/Reports/test.rdlc");

            //DataSet  
            //testDataSet frndDataSet = new testDataSet();


            // Create Report DataSource  
            ReportDataSource reportdatasource = new ReportDataSource();
            reportdatasource.Name = "DataSet1";

            //List<users> li = new List<users>();

            var useaccess = objIUserQuery.useraccessslist();
            var useraccessscreen = objIUserQuery.useraccessscreenlist();
            var result = (from a in useraccessscreen
                          join
                          s in useaccess on a.useraccesssid equals s.id
                          select new
                          {
                              a.id,
                              a.modulename,
                              a.useraccesssid,
                              a.usersid,
                              s.role,
                              s.description
                          }).ToList();


            List<orgUsermanage.Controllers.ViewModels.reportvm.managereport> li = new List<orgUsermanage.Controllers.ViewModels.reportvm.managereport>();

            foreach(var i in result)
            {
                orgUsermanage.Controllers.ViewModels.reportvm.managereport r = new orgUsermanage.Controllers.ViewModels.reportvm.managereport();
                r.id = i.id;
                r.role = i.role;
                r.description = i.description;
                r.modulename = i.modulename;
                r.useraccesssid = objIUserQuery.useraccessslist().Where(x => x.id == i.useraccesssid).SingleOrDefault().role;
                r.usersid = objIUserQuery.userlist().Where(x => x.usersid == i.usersid).SingleOrDefault().user_name;
               
                li.Add(r);
            }


           // reportdatasource.Value = result;
            reportdatasource.Value = li;
            

            rv.LocalReport.DataSources.Add(reportdatasource);
            //rv.LocalReport.Refresh();
            //rv.DataBind();
            // Variables  
            Warning[] warnings = null;
            string reportType = ReportType;
            string mimeTime = null;
            string encoding = null;
            string extension = null;
            if (reportType == "Excel")
            {
                extension = "xlsx";
            }
            if (reportType == "Word")
            {
                extension = "docx";
            }
            if (reportType == "PDF")
            {
                extension = "pdf";
            }
            // Setup the report viewer object and get the array of bytes  

            string[] streams = null;
            byte[] renderdByte;

            renderdByte = rv.LocalReport.Render(reportType, "", out mimeTime, out encoding, out extension, out streams, out warnings);
            Response.AddHeader("content-disposition", "Attachment;fileName=UserReport." + extension);
            return File(renderdByte, extension);
        }
    }
}
