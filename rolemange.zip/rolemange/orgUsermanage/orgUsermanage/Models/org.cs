﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace orgUsermanage.Models
{
    public class org
    {
        public virtual int org_id { get; set; }
        public virtual string org_name { get; set; }
        public virtual string org_address { get; set; }
        public virtual string org_email { get; set; }
        public virtual string phone { get; set; }
        public virtual DateTime created_date { get; set; }
        public virtual string created_By { get; set; }
        public virtual DateTime modified_date { get; set; }
    }
}