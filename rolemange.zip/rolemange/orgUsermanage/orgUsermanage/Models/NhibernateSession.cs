﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NHibernate;
using NHibernate.Cfg;


namespace orgUsermanage.Models
{
    public class NhibernateSession
    {
        public static ISession OpenSession()
        {
            var configuration = new Configuration();
            var configurationPath = HttpContext.Current.Server.MapPath(@"~\nhibernate.config");
            configuration.Configure(configurationPath);
            var orgConfigurationFile = HttpContext.Current.Server.MapPath(@"~\org.hbm.xml");
            var usersConfigurationFile = HttpContext.Current.Server.MapPath(@"~\users.hbm.xml");
            var useraccesssConfigurationFile = HttpContext.Current.Server.MapPath(@"~\useraccesss.hbm.xml");
            var useraccessscreenConfigurationFile = HttpContext.Current.Server.MapPath(@"~\useraccessscreen.hbm.xml");


            configuration.AddFile(orgConfigurationFile);
            configuration.AddFile(usersConfigurationFile);
            configuration.AddFile(useraccesssConfigurationFile);
            configuration.AddFile(useraccessscreenConfigurationFile);

            ISessionFactory sessionFactory = configuration.BuildSessionFactory();
            return sessionFactory.OpenSession();

        }
    }
}