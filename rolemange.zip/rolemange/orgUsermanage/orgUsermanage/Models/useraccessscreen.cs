﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace orgUsermanage.Models
{
    public class useraccessscreen
    {

        public virtual int id { get; set; }

        public virtual string modulename { get; set; }

        public virtual bool adddata { get; set; }
        public virtual bool editdata { get; set; }
        public virtual bool deletedata { get; set; }

        public virtual int useraccesssid { get; set; }

        public virtual int usersid { get; set; }
    }
}