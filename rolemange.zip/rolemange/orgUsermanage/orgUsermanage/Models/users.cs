﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace orgUsermanage.Models
{
    public class users
    {
        public virtual int usersid { get; set; }
        public virtual string user_name { get; set; }
        public virtual string user_email { get; set; }
        public virtual string phone { get; set; }
        public virtual string password { get; set; }
        public virtual int org_id { get; set; }
        public virtual DateTime created_date { get; set; }
        public virtual string created_By { get; set; }
        public virtual DateTime modified_date { get; set; }
        public virtual int roleid { get; set; }
        public virtual bool Flag { get; set; }
    }
}