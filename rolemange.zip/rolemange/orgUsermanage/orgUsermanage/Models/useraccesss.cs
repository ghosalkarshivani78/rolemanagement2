﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace orgUsermanage.Models
{
    public class useraccesss
    {
        public virtual int id { get; set; }

        public virtual string role { get; set; }

        public virtual string description { get; set; }
    }
}